// This library is provided under the terms of a non-commercial license.
// 
// Please refer to the source repository for details:
// 
// https://github.com/stepfunc/dnp3/blob/master/LICENSE.txt
// 
// Please contact Step Function I/O if you are interested in commercial license:
// 
// info@stepfunc.io
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#define DNP3RS_VERSION_MAJOR 0
#define DNP3RS_VERSION_MINOR 1
#define DNP3RS_VERSION_PATCH 0
#define DNP3RS_VERSION_STRING "0.1.0"

#include <stdbool.h>
#include <stdint.h>

/// @file

/// @brief Object value is 'good' / 'valid' / 'nominal'
#define FLAG_ONLINE 0x01
/// @brief Object value has not been updated since device restart
#define FLAG_RESTART 0x02
/// @brief Object value represents the last value available before a communication failure occurred. Should never be set by originating devices
#define FLAG_COMM_LOST 0x04
/// @brief Object value is overridden in a downstream reporting device
#define FLAG_REMOTE_FORCED 0x08
/// @brief Object value is overridden by the device reporting this flag
#define FLAG_LOCAL_FORCED 0x10
/// @brief Object value is changing state rapidly (device dependent meaning)
#define FLAG_CHATTER_FILTER 0x20
/// @brief Object's true exceeds the measurement range of the reported variation
#define FLAG_OVER_RANGE 0x20
/// @brief Reported counter value cannot be compared against a prior value to obtain the correct count difference
#define FLAG_DISCONTINUITY 0x40
/// @brief Object's value might not have the expected level of accuracy
#define FLAG_REFERENCE_ERR 0x40

typedef struct control_t control_t;

/// @brief APDU Control field
typedef struct control_t
{
    /// @brief First fragment in the message
    bool fir;
    /// @brief Final fragment of the message
    bool fin;
    /// @brief Requires confirmation
    bool con;
    /// @brief Unsolicited response
    bool uns;
    /// @brief Sequence number
    uint8_t seq;
} control_t;

static control_t control_init(bool fir, bool fin, bool con, bool uns, uint8_t seq)
{
    return (control_t)
    {
        .fir = fir,
        .fin = fin,
        .con = con,
        .uns = uns,
        .seq = seq,
    };
}

/// @brief Trip-Close Code field, used in conjunction with @ref op_type_t to specify a control operation
typedef enum trip_close_code_t
{
    /// @brief NUL (0)
    TripCloseCode_Nul = 0,
    /// @brief CLOSE (1)
    TripCloseCode_Close = 1,
    /// @brief TRIP (2)
    TripCloseCode_Trip = 2,
    /// @brief RESERVED (3)
    TripCloseCode_Reserved = 3,
} trip_close_code_t;

static const char* TripCloseCode_to_string(trip_close_code_t value)
{
    switch (value)
    {
        case TripCloseCode_Nul: return "Nul";
        case TripCloseCode_Close: return "Close";
        case TripCloseCode_Trip: return "Trip";
        case TripCloseCode_Reserved: return "Reserved";
        default: return "";
    }
}

/// @brief Operation Type field, used in conjunction with @ref trip_close_code_t to specify a control operation
typedef enum op_type_t
{
    /// @brief NUL (0)
    OpType_Nul = 0,
    /// @brief PULSE_ON (1)
    OpType_PulseOn = 1,
    /// @brief PULSE_OFF (2)
    OpType_PulseOff = 2,
    /// @brief LATCH_ON (3)
    OpType_LatchOn = 3,
    /// @brief LATCH_OFF(4)
    OpType_LatchOff = 4,
} op_type_t;

static const char* OpType_to_string(op_type_t value)
{
    switch (value)
    {
        case OpType_Nul: return "Nul";
        case OpType_PulseOn: return "PulseOn";
        case OpType_PulseOff: return "PulseOff";
        case OpType_LatchOn: return "LatchOn";
        case OpType_LatchOff: return "LatchOff";
        default: return "";
    }
}

typedef struct control_code_t control_code_t;

/// @brief CROB (@ref g12v1_t) control code
typedef struct control_code_t
{
    /// @brief This field is used in conjunction with the `op_type` field to specify a control operation
    trip_close_code_t tcc;
    /// @brief Support for this field is optional. When the clear bit is set, the device shall remove pending control commands for that index and stop any control operation that is in progress for that index. The indexed point shall go to the state that it would have if the command were allowed to complete normally.
    bool clear;
    /// @brief This field is obsolete and should always be 0
    /// @note Default value is false
    bool queue;
    /// @brief This field is used in conjunction with the `tcc` field to specify a control operation
    op_type_t op_type;
} control_code_t;

static control_code_t control_code_init(trip_close_code_t tcc, bool clear, op_type_t op_type)
{
    return (control_code_t)
    {
        .tcc = tcc,
        .clear = clear,
        .queue = false,
        .op_type = op_type,
    };
}

typedef struct g12v1_t g12v1_t;

/// @brief Control Relay Output Block
typedef struct g12v1_t
{
    /// @brief Control code
    control_code_t code;
    /// @brief Count
    uint8_t count;
    /// @brief Duration the output drive remains active (in milliseconds)
    uint32_t on_time;
    /// @brief Duration the output drive remains non-active (in milliseconds)
    uint32_t off_time;
} g12v1_t;

static g12v1_t g12v1_init(control_code_t code, uint8_t count, uint32_t on_time, uint32_t off_time)
{
    return (g12v1_t)
    {
        .code = code,
        .count = count,
        .on_time = on_time,
        .off_time = off_time,
    };
}

typedef struct flags_t flags_t;

/// @brief Collection of individual flag bits represented by an underlying mask value
typedef struct flags_t
{
    /// @brief bit-mask representing a set of individual flag bits
    uint8_t value;
} flags_t;

static flags_t flags_init(uint8_t value)
{
    return (flags_t)
    {
        .value = value,
    };
}

/// @brief Timestamp quality
typedef enum time_quality_t
{
    /// @brief The timestamp is UTC synchronized at the remote device
    TimeQuality_Synchronized = 0,
    /// @brief The device indicates the timestamp may be not be synchronized
    TimeQuality_NotSynchronized = 1,
    /// @brief Timestamp is not valid, ignore the value and use a local timestamp
    TimeQuality_Invalid = 2,
} time_quality_t;

static const char* TimeQuality_to_string(time_quality_t value)
{
    switch (value)
    {
        case TimeQuality_Synchronized: return "Synchronized";
        case TimeQuality_NotSynchronized: return "NotSynchronized";
        case TimeQuality_Invalid: return "Invalid";
        default: return "";
    }
}

typedef struct timestamp_t timestamp_t;

/// @brief Timestamp value
typedef struct timestamp_t
{
    /// @brief Timestamp value
    uint64_t value;
    /// @brief Timestamp quality
    time_quality_t quality;
} timestamp_t;

static timestamp_t timestamp_init(uint64_t value, time_quality_t quality)
{
    return (timestamp_t)
    {
        .value = value,
        .quality = quality,
    };
}

/// @brief Creates an invalid timestamp struct
/// @return Invalid timestamp
timestamp_t timestamp_invalid();

/// @brief Creates a synchronized timestamp struct
/// @param value Timestamp value in milliseconds since EPOCH
/// @return Synchronized timestamp
timestamp_t timestamp_synchronized(uint64_t value);

/// @brief Creates a not synchronized timestamp struct
/// @param value Timestamp value in milliseconds since EPOCH
/// @return Not synchronized timestamp
timestamp_t timestamp_not_synchronized(uint64_t value);


/// @brief Double-bit binary input value
typedef enum double_bit_t
{
    /// @brief Transition between conditions
    DoubleBit_Intermediate = 0,
    /// @brief Determined to be OFF
    DoubleBit_DeterminedOff = 1,
    /// @brief Determined to be ON
    DoubleBit_DeterminedOn = 2,
    /// @brief Abnormal or custom condition
    DoubleBit_Indeterminate = 3,
} double_bit_t;

static const char* DoubleBit_to_string(double_bit_t value)
{
    switch (value)
    {
        case DoubleBit_Intermediate: return "Intermediate";
        case DoubleBit_DeterminedOff: return "DeterminedOff";
        case DoubleBit_DeterminedOn: return "DeterminedOn";
        case DoubleBit_Indeterminate: return "Indeterminate";
        default: return "";
    }
}

typedef struct binary_t binary_t;

/// @brief Binary point
typedef struct binary_t
{
    /// @brief Point index
    uint16_t index;
    /// @brief Point value
    bool value;
    /// @brief Point flags
    flags_t flags;
    /// @brief Point timestamp
    timestamp_t time;
} binary_t;

static binary_t binary_init(uint16_t index, bool value, flags_t flags, timestamp_t time)
{
    return (binary_t)
    {
        .index = index,
        .value = value,
        .flags = flags,
        .time = time,
    };
}

/// @brief Iterator of @ref binary_t. See @ref binary_next.
typedef struct binary_iterator_t binary_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
binary_t* binary_next(binary_iterator_t* it);


typedef struct double_bit_binary_t double_bit_binary_t;

/// @brief DoubleBitBinary point
typedef struct double_bit_binary_t
{
    /// @brief Point index
    uint16_t index;
    /// @brief Point value
    double_bit_t value;
    /// @brief Point flags
    flags_t flags;
    /// @brief Point timestamp
    timestamp_t time;
} double_bit_binary_t;

static double_bit_binary_t double_bit_binary_init(uint16_t index, double_bit_t value, flags_t flags, timestamp_t time)
{
    return (double_bit_binary_t)
    {
        .index = index,
        .value = value,
        .flags = flags,
        .time = time,
    };
}

/// @brief Iterator of @ref double_bit_binary_t. See @ref doublebitbinary_next.
typedef struct double_bit_binary_iterator_t double_bit_binary_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
double_bit_binary_t* doublebitbinary_next(double_bit_binary_iterator_t* it);


typedef struct binary_output_status_t binary_output_status_t;

/// @brief BinaryOutputStatus point
typedef struct binary_output_status_t
{
    /// @brief Point index
    uint16_t index;
    /// @brief Point value
    bool value;
    /// @brief Point flags
    flags_t flags;
    /// @brief Point timestamp
    timestamp_t time;
} binary_output_status_t;

static binary_output_status_t binary_output_status_init(uint16_t index, bool value, flags_t flags, timestamp_t time)
{
    return (binary_output_status_t)
    {
        .index = index,
        .value = value,
        .flags = flags,
        .time = time,
    };
}

/// @brief Iterator of @ref binary_output_status_t. See @ref binaryoutputstatus_next.
typedef struct binary_output_status_iterator_t binary_output_status_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
binary_output_status_t* binaryoutputstatus_next(binary_output_status_iterator_t* it);


typedef struct counter_t counter_t;

/// @brief Counter point
typedef struct counter_t
{
    /// @brief Point index
    uint16_t index;
    /// @brief Point value
    uint32_t value;
    /// @brief Point flags
    flags_t flags;
    /// @brief Point timestamp
    timestamp_t time;
} counter_t;

static counter_t counter_init(uint16_t index, uint32_t value, flags_t flags, timestamp_t time)
{
    return (counter_t)
    {
        .index = index,
        .value = value,
        .flags = flags,
        .time = time,
    };
}

/// @brief Iterator of @ref counter_t. See @ref counter_next.
typedef struct counter_iterator_t counter_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
counter_t* counter_next(counter_iterator_t* it);


typedef struct frozen_counter_t frozen_counter_t;

/// @brief FrozenCounter point
typedef struct frozen_counter_t
{
    /// @brief Point index
    uint16_t index;
    /// @brief Point value
    uint32_t value;
    /// @brief Point flags
    flags_t flags;
    /// @brief Point timestamp
    timestamp_t time;
} frozen_counter_t;

static frozen_counter_t frozen_counter_init(uint16_t index, uint32_t value, flags_t flags, timestamp_t time)
{
    return (frozen_counter_t)
    {
        .index = index,
        .value = value,
        .flags = flags,
        .time = time,
    };
}

/// @brief Iterator of @ref frozen_counter_t. See @ref frozencounter_next.
typedef struct frozen_counter_iterator_t frozen_counter_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
frozen_counter_t* frozencounter_next(frozen_counter_iterator_t* it);


typedef struct analog_t analog_t;

/// @brief Analog point
typedef struct analog_t
{
    /// @brief Point index
    uint16_t index;
    /// @brief Point value
    double value;
    /// @brief Point flags
    flags_t flags;
    /// @brief Point timestamp
    timestamp_t time;
} analog_t;

static analog_t analog_init(uint16_t index, double value, flags_t flags, timestamp_t time)
{
    return (analog_t)
    {
        .index = index,
        .value = value,
        .flags = flags,
        .time = time,
    };
}

/// @brief Iterator of @ref analog_t. See @ref analog_next.
typedef struct analog_iterator_t analog_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
analog_t* analog_next(analog_iterator_t* it);


typedef struct analog_output_status_t analog_output_status_t;

/// @brief AnalogOutputStatus point
typedef struct analog_output_status_t
{
    /// @brief Point index
    uint16_t index;
    /// @brief Point value
    double value;
    /// @brief Point flags
    flags_t flags;
    /// @brief Point timestamp
    timestamp_t time;
} analog_output_status_t;

static analog_output_status_t analog_output_status_init(uint16_t index, double value, flags_t flags, timestamp_t time)
{
    return (analog_output_status_t)
    {
        .index = index,
        .value = value,
        .flags = flags,
        .time = time,
    };
}

/// @brief Iterator of @ref analog_output_status_t. See @ref analogoutputstatus_next.
typedef struct analog_output_status_iterator_t analog_output_status_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
analog_output_status_t* analogoutputstatus_next(analog_output_status_iterator_t* it);


/// @brief State of the serial port
typedef enum port_state_t
{
    /// @brief Disabled until enabled
    PortState_Disabled = 0,
    /// @brief Waiting to perform an open retry
    PortState_Wait = 1,
    /// @brief Port is open
    PortState_Open = 2,
    /// @brief Task has been shut down
    PortState_Shutdown = 3,
} port_state_t;

static const char* PortState_to_string(port_state_t value)
{
    switch (value)
    {
        case PortState_Disabled: return "Disabled";
        case PortState_Wait: return "Wait";
        case PortState_Open: return "Open";
        case PortState_Shutdown: return "Shutdown";
        default: return "";
    }
}

/// @brief Callback interface for receiving updates about the state of a serial port
typedef struct port_state_listener_t
{
    
    /// @brief Invoked when the serial port changes state
    /// @param state New state of the port
    /// @param ctx Context data
    void (*on_change)(port_state_t, void*);
    /// @brief Callback when the underlying owner doesn't need the callback anymore
    /// @param arg Context data
    void (*on_destroy)(void* arg);
    /// @brief Context data
    void* ctx;
} port_state_listener_t;

/// @brief Group/Variation
typedef enum variation_t
{
    /// @brief Binary Input - Default variation
    Variation_Group1Var0 = 0,
    /// @brief Binary Input - Packed format
    Variation_Group1Var1 = 1,
    /// @brief Binary Input - With flags
    Variation_Group1Var2 = 2,
    /// @brief Binary Input Event - Default variation
    Variation_Group2Var0 = 3,
    /// @brief Binary Input Event - Without time
    Variation_Group2Var1 = 4,
    /// @brief Binary Input Event - With absolute time
    Variation_Group2Var2 = 5,
    /// @brief Binary Input Event - With relative time
    Variation_Group2Var3 = 6,
    /// @brief Double-bit Binary Input - Default variation
    Variation_Group3Var0 = 7,
    /// @brief Double-bit Binary Input - Packed format
    Variation_Group3Var1 = 8,
    /// @brief Double-bit Binary Input - With flags
    Variation_Group3Var2 = 9,
    /// @brief Double-bit Binary Input Event - Default variation
    Variation_Group4Var0 = 10,
    /// @brief Double-bit Binary Input Event - Without time
    Variation_Group4Var1 = 11,
    /// @brief Double-bit Binary Input Event - With absolute time
    Variation_Group4Var2 = 12,
    /// @brief Double-bit Binary Input Event - With relative time
    Variation_Group4Var3 = 13,
    /// @brief Binary Output - Default variation
    Variation_Group10Var0 = 14,
    /// @brief Binary Output - Packed format
    Variation_Group10Var1 = 15,
    /// @brief Binary Output - With flags
    Variation_Group10Var2 = 16,
    /// @brief Binary Output Event - Default variation
    Variation_Group11Var0 = 17,
    /// @brief Binary Output Event - Without time
    Variation_Group11Var1 = 18,
    /// @brief Binary Output Event - With time
    Variation_Group11Var2 = 19,
    /// @brief Binary Output Command - Control Relay Output Block
    Variation_Group12Var0 = 20,
    /// @brief Binary Output Command - Pattern Control Block
    Variation_Group12Var1 = 21,
    /// @brief Counter - Default variation
    Variation_Group20Var0 = 22,
    /// @brief Counter - 32-bit with flags
    Variation_Group20Var1 = 23,
    /// @brief Counter - 16-bit with flags
    Variation_Group20Var2 = 24,
    /// @brief Counter - 32-bit without flag
    Variation_Group20Var5 = 25,
    /// @brief Counter - 16-bit without flag
    Variation_Group20Var6 = 26,
    /// @brief Frozen Counter - Default variation
    Variation_Group21Var0 = 27,
    /// @brief Frozen Counter - 32-bit with flags
    Variation_Group21Var1 = 28,
    /// @brief Frozen Counter - 16-bit with flags
    Variation_Group21Var2 = 29,
    /// @brief Frozen Counter - 32-bit with flags and time
    Variation_Group21Var5 = 30,
    /// @brief Frozen Counter - 16-bit with flags and time
    Variation_Group21Var6 = 31,
    /// @brief Frozen Counter - 32-bit without flag
    Variation_Group21Var9 = 32,
    /// @brief Frozen Counter - 16-bit without flag
    Variation_Group21Var10 = 33,
    /// @brief Counter Event - Default variation
    Variation_Group22Var0 = 34,
    /// @brief Counter Event - 32-bit with flags
    Variation_Group22Var1 = 35,
    /// @brief Counter Event - 16-bit with flags
    Variation_Group22Var2 = 36,
    /// @brief Counter Event - 32-bit with flags and time
    Variation_Group22Var5 = 37,
    /// @brief Counter Event - 16-bit with flags and time
    Variation_Group22Var6 = 38,
    /// @brief Frozen Counter Event - Default variation
    Variation_Group23Var0 = 39,
    /// @brief Frozen Counter Event - 32-bit with flags
    Variation_Group23Var1 = 40,
    /// @brief Frozen Counter Event - 16-bit with flags
    Variation_Group23Var2 = 41,
    /// @brief Frozen Counter Event - 32-bit with flags and time
    Variation_Group23Var5 = 42,
    /// @brief Frozen Counter Event - 16-bit with flags and time
    Variation_Group23Var6 = 43,
    /// @brief Analog Input - Default variation
    Variation_Group30Var0 = 44,
    /// @brief Analog Input - 32-bit with flags
    Variation_Group30Var1 = 45,
    /// @brief Analog Input - 16-bit with flags
    Variation_Group30Var2 = 46,
    /// @brief Analog Input - 32-bit without flag
    Variation_Group30Var3 = 47,
    /// @brief Analog Input - 16-bit without flag
    Variation_Group30Var4 = 48,
    /// @brief Analog Input - Single-precision floating point with flags
    Variation_Group30Var5 = 49,
    /// @brief Analog Input - Double-precision floating point with flags
    Variation_Group30Var6 = 50,
    /// @brief Analog Input Event - Default variation
    Variation_Group32Var0 = 51,
    /// @brief Analog Input Event - 32-bit without time
    Variation_Group32Var1 = 52,
    /// @brief Analog Input Event - 16-bit without time
    Variation_Group32Var2 = 53,
    /// @brief Analog Input Event - 32-bit with time
    Variation_Group32Var3 = 54,
    /// @brief Analog Input Event - 16-bit with time
    Variation_Group32Var4 = 55,
    /// @brief Analog Input Event - Single-precision floating point without time
    Variation_Group32Var5 = 56,
    /// @brief Analog Input Event - Double-precision floating point without time
    Variation_Group32Var6 = 57,
    /// @brief Analog Input Event - Single-precision floating point with time
    Variation_Group32Var7 = 58,
    /// @brief Analog Input Event - Double-precision floating point with time
    Variation_Group32Var8 = 59,
    /// @brief Analog Output Status - Default variation
    Variation_Group40Var0 = 60,
    /// @brief Analog Output Status - 32-bit with flags
    Variation_Group40Var1 = 61,
    /// @brief Analog Output Status - 16-bit with flags
    Variation_Group40Var2 = 62,
    /// @brief Analog Output Status - Single-precision floating point with flags
    Variation_Group40Var3 = 63,
    /// @brief Analog Output Status - Double-precision floating point with flags
    Variation_Group40Var4 = 64,
    /// @brief Analog Output - Default variation
    Variation_Group41Var0 = 65,
    /// @brief Analog Output - 32-bit
    Variation_Group41Var1 = 66,
    /// @brief Analog Output - 16-bit
    Variation_Group41Var2 = 67,
    /// @brief Analog Output - Single-precision floating point
    Variation_Group41Var3 = 68,
    /// @brief Analog Output - Double-precision floating point
    Variation_Group41Var4 = 69,
    /// @brief Analog Output Event - Default variation
    Variation_Group42Var0 = 70,
    /// @brief Analog Output Event - 32-bit without time
    Variation_Group42Var1 = 71,
    /// @brief Analog Output Event - 16-bit without time
    Variation_Group42Var2 = 72,
    /// @brief Analog Output Event - 32-bit with time
    Variation_Group42Var3 = 73,
    /// @brief Analog Output Event - 16-bit with time
    Variation_Group42Var4 = 74,
    /// @brief Analog Output Event - Single-precision floating point without time
    Variation_Group42Var5 = 75,
    /// @brief Analog Output Event - Double-precision floating point without time
    Variation_Group42Var6 = 76,
    /// @brief Analog Output Event - Single-preicions floating point with time
    Variation_Group42Var7 = 77,
    /// @brief Analog Output Event - Double-preicions floating point with time
    Variation_Group42Var8 = 78,
    /// @brief Time and Date - Absolute time
    Variation_Group50Var1 = 79,
    /// @brief Time and Date - Absolute time at last recorded time
    Variation_Group50Var3 = 80,
    /// @brief Time and Date - Indexed absolute time and long interval
    Variation_Group50Var4 = 81,
    /// @brief Time and date CTO - Absolute time, synchronized
    Variation_Group51Var1 = 82,
    /// @brief Time and date CTO - Absolute time, unsynchronized
    Variation_Group51Var2 = 83,
    /// @brief Time delay - Coarse
    Variation_Group52Var1 = 84,
    /// @brief Time delay - Fine
    Variation_Group52Var2 = 85,
    /// @brief Class objects - Class 0 data
    Variation_Group60Var1 = 86,
    /// @brief Class objects - Class 1 data
    Variation_Group60Var2 = 87,
    /// @brief Class objects - Class 2 data
    Variation_Group60Var3 = 88,
    /// @brief Class objects - Class 3 data
    Variation_Group60Var4 = 89,
    /// @brief Internal Indications - Packed format
    Variation_Group80Var1 = 90,
    /// @brief Octet String
    Variation_Group110 = 91,
    /// @brief Octet String Event
    Variation_Group111 = 92,
} variation_t;

static const char* Variation_to_string(variation_t value)
{
    switch (value)
    {
        case Variation_Group1Var0: return "Group1Var0";
        case Variation_Group1Var1: return "Group1Var1";
        case Variation_Group1Var2: return "Group1Var2";
        case Variation_Group2Var0: return "Group2Var0";
        case Variation_Group2Var1: return "Group2Var1";
        case Variation_Group2Var2: return "Group2Var2";
        case Variation_Group2Var3: return "Group2Var3";
        case Variation_Group3Var0: return "Group3Var0";
        case Variation_Group3Var1: return "Group3Var1";
        case Variation_Group3Var2: return "Group3Var2";
        case Variation_Group4Var0: return "Group4Var0";
        case Variation_Group4Var1: return "Group4Var1";
        case Variation_Group4Var2: return "Group4Var2";
        case Variation_Group4Var3: return "Group4Var3";
        case Variation_Group10Var0: return "Group10Var0";
        case Variation_Group10Var1: return "Group10Var1";
        case Variation_Group10Var2: return "Group10Var2";
        case Variation_Group11Var0: return "Group11Var0";
        case Variation_Group11Var1: return "Group11Var1";
        case Variation_Group11Var2: return "Group11Var2";
        case Variation_Group12Var0: return "Group12Var0";
        case Variation_Group12Var1: return "Group12Var1";
        case Variation_Group20Var0: return "Group20Var0";
        case Variation_Group20Var1: return "Group20Var1";
        case Variation_Group20Var2: return "Group20Var2";
        case Variation_Group20Var5: return "Group20Var5";
        case Variation_Group20Var6: return "Group20Var6";
        case Variation_Group21Var0: return "Group21Var0";
        case Variation_Group21Var1: return "Group21Var1";
        case Variation_Group21Var2: return "Group21Var2";
        case Variation_Group21Var5: return "Group21Var5";
        case Variation_Group21Var6: return "Group21Var6";
        case Variation_Group21Var9: return "Group21Var9";
        case Variation_Group21Var10: return "Group21Var10";
        case Variation_Group22Var0: return "Group22Var0";
        case Variation_Group22Var1: return "Group22Var1";
        case Variation_Group22Var2: return "Group22Var2";
        case Variation_Group22Var5: return "Group22Var5";
        case Variation_Group22Var6: return "Group22Var6";
        case Variation_Group23Var0: return "Group23Var0";
        case Variation_Group23Var1: return "Group23Var1";
        case Variation_Group23Var2: return "Group23Var2";
        case Variation_Group23Var5: return "Group23Var5";
        case Variation_Group23Var6: return "Group23Var6";
        case Variation_Group30Var0: return "Group30Var0";
        case Variation_Group30Var1: return "Group30Var1";
        case Variation_Group30Var2: return "Group30Var2";
        case Variation_Group30Var3: return "Group30Var3";
        case Variation_Group30Var4: return "Group30Var4";
        case Variation_Group30Var5: return "Group30Var5";
        case Variation_Group30Var6: return "Group30Var6";
        case Variation_Group32Var0: return "Group32Var0";
        case Variation_Group32Var1: return "Group32Var1";
        case Variation_Group32Var2: return "Group32Var2";
        case Variation_Group32Var3: return "Group32Var3";
        case Variation_Group32Var4: return "Group32Var4";
        case Variation_Group32Var5: return "Group32Var5";
        case Variation_Group32Var6: return "Group32Var6";
        case Variation_Group32Var7: return "Group32Var7";
        case Variation_Group32Var8: return "Group32Var8";
        case Variation_Group40Var0: return "Group40Var0";
        case Variation_Group40Var1: return "Group40Var1";
        case Variation_Group40Var2: return "Group40Var2";
        case Variation_Group40Var3: return "Group40Var3";
        case Variation_Group40Var4: return "Group40Var4";
        case Variation_Group41Var0: return "Group41Var0";
        case Variation_Group41Var1: return "Group41Var1";
        case Variation_Group41Var2: return "Group41Var2";
        case Variation_Group41Var3: return "Group41Var3";
        case Variation_Group41Var4: return "Group41Var4";
        case Variation_Group42Var0: return "Group42Var0";
        case Variation_Group42Var1: return "Group42Var1";
        case Variation_Group42Var2: return "Group42Var2";
        case Variation_Group42Var3: return "Group42Var3";
        case Variation_Group42Var4: return "Group42Var4";
        case Variation_Group42Var5: return "Group42Var5";
        case Variation_Group42Var6: return "Group42Var6";
        case Variation_Group42Var7: return "Group42Var7";
        case Variation_Group42Var8: return "Group42Var8";
        case Variation_Group50Var1: return "Group50Var1";
        case Variation_Group50Var3: return "Group50Var3";
        case Variation_Group50Var4: return "Group50Var4";
        case Variation_Group51Var1: return "Group51Var1";
        case Variation_Group51Var2: return "Group51Var2";
        case Variation_Group52Var1: return "Group52Var1";
        case Variation_Group52Var2: return "Group52Var2";
        case Variation_Group60Var1: return "Group60Var1";
        case Variation_Group60Var2: return "Group60Var2";
        case Variation_Group60Var3: return "Group60Var3";
        case Variation_Group60Var4: return "Group60Var4";
        case Variation_Group80Var1: return "Group80Var1";
        case Variation_Group110: return "Group110";
        case Variation_Group111: return "Group111";
        default: return "";
    }
}

/// @brief Handle to the underlying runtime
typedef struct runtime_t runtime_t;

typedef struct runtime_config_t runtime_config_t;

/// @brief Runtime configuration
typedef struct runtime_config_t
{
    /// @brief Number of runtime threads to spawn. For a guess of the number of CPU cores, use 0.
    /// 
    /// Even if tons of connections are expected, it is preferred to use a value around the number of CPU cores for better performances. The library uses an efficient thread pool polling mechanism.
    /// @note Default value is 0
    uint16_t num_core_threads;
} runtime_config_t;

static runtime_config_t runtime_config_init()
{
    return (runtime_config_t)
    {
        .num_core_threads = 0,
    };
}

/// @brief Creates a new runtime for running the protocol stack.
/// 
/// @warning The runtime should be kept alive for as long as it's needed and it should be released with @ref runtime_destroy
/// @param config Runtime configuration
/// @return Handle to the created runtime, @p NULL if an error occurred
runtime_t* runtime_new(runtime_config_t config);

/// @brief Destroy a runtime.
/// 
/// This method will gracefully wait for all asynchronous operation to end before returning
/// @param runtime Runtime to destroy
void runtime_destroy(runtime_t* runtime);


/// @brief Log level
/// 
/// Used in @ref logger_t.on_message callback to identify the log level of a message.
typedef enum log_level_t
{
    /// @brief Error log level
    LogLevel_Error = 0,
    /// @brief Warning log level
    LogLevel_Warn = 1,
    /// @brief Information log level
    LogLevel_Info = 2,
    /// @brief Debugging log level
    LogLevel_Debug = 3,
    /// @brief Trace log level
    LogLevel_Trace = 4,
} log_level_t;

static const char* LogLevel_to_string(log_level_t value)
{
    switch (value)
    {
        case LogLevel_Error: return "Error";
        case LogLevel_Warn: return "Warn";
        case LogLevel_Info: return "Info";
        case LogLevel_Debug: return "Debug";
        case LogLevel_Trace: return "Trace";
        default: return "";
    }
}

/// @brief Describes if and how the time will be formatted in log messages
typedef enum time_format_t
{
    /// @brief Don't format the timestamp as part of the message
    TimeFormat_None = 0,
    /// @brief Format the time using RFC 3339
    TimeFormat_Rfc3339 = 1,
    /// @brief Format the time in a human readable format e.g. 'Jun 25 14:27:12.955'
    TimeFormat_System = 2,
} time_format_t;

static const char* TimeFormat_to_string(time_format_t value)
{
    switch (value)
    {
        case TimeFormat_None: return "None";
        case TimeFormat_Rfc3339: return "Rfc3339";
        case TimeFormat_System: return "System";
        default: return "";
    }
}

/// @brief Describes how each log event is formatted
typedef enum log_output_format_t
{
    /// @brief A simple text-based format
    LogOutputFormat_Text = 0,
    /// @brief Output formatted as JSON
    LogOutputFormat_Json = 1,
} log_output_format_t;

static const char* LogOutputFormat_to_string(log_output_format_t value)
{
    switch (value)
    {
        case LogOutputFormat_Text: return "Text";
        case LogOutputFormat_Json: return "Json";
        default: return "";
    }
}

typedef struct logging_config_t logging_config_t;

/// @brief Logging configuration options
typedef struct logging_config_t
{
    /// @brief logging level
    /// @note Default value is @ref LogLevel_Info
    log_level_t level;
    /// @brief output formatting options
    /// @note Default value is @ref LogOutputFormat_Text
    log_output_format_t output_format;
    /// @brief optional time format
    /// @note Default value is @ref TimeFormat_System
    time_format_t time_format;
    /// @brief optionally print the log level as part to the message string
    /// @note Default value is true
    bool print_level;
    /// @brief optionally print the underlying Rust module information to the message string
    /// @note Default value is false
    bool print_module_info;
} logging_config_t;

static logging_config_t logging_config_init()
{
    return (logging_config_t)
    {
        .level = LogLevel_Info,
        .output_format = LogOutputFormat_Text,
        .time_format = TimeFormat_System,
        .print_level = true,
        .print_module_info = false,
    };
}

/// @brief Logging interface that receives the log messages and writes them somewhere.
typedef struct logger_t
{
    
    /// @brief Called when a log message was received and should be logged
    /// @param level Level of the message
    /// @param message Actual formatted message
    /// @param ctx Context data
    void (*on_message)(log_level_t, const char*, void*);
    /// @brief Callback when the underlying owner doesn't need the callback anymore
    /// @param arg Context data
    void (*on_destroy)(void* arg);
    /// @brief Context data
    void* ctx;
} logger_t;

/// @brief Set the callback that will receive all the log messages
/// 
/// There is only a single globally allocated logger. Calling this method a second time will result in a panic.
/// 
/// If this method is never called, no logging will be performed.
/// @param config Configuration options for logging
/// @param logger Logger that will receive each logged message
void configure_logging(logging_config_t config, logger_t logger);

/// @brief Provides a static method for configuring logging
typedef struct logging_t logging_t;


/// @brief Controls how transmitted and received application-layer fragments are decoded at the INFO log level
typedef enum app_decode_level_t
{
    /// @brief Decode nothing
    AppDecodeLevel_Nothing = 0,
    /// @brief  Decode the header-only
    AppDecodeLevel_Header = 1,
    /// @brief Decode the header and the object headers
    AppDecodeLevel_ObjectHeaders = 2,
    /// @brief Decode the header, the object headers, and the object values
    AppDecodeLevel_ObjectValues = 3,
} app_decode_level_t;

static const char* AppDecodeLevel_to_string(app_decode_level_t value)
{
    switch (value)
    {
        case AppDecodeLevel_Nothing: return "Nothing";
        case AppDecodeLevel_Header: return "Header";
        case AppDecodeLevel_ObjectHeaders: return "ObjectHeaders";
        case AppDecodeLevel_ObjectValues: return "ObjectValues";
        default: return "";
    }
}

/// @brief Controls how transmitted and received transport segments are decoded at the INFO log level
typedef enum transport_decode_level_t
{
    /// @brief Decode nothing
    TransportDecodeLevel_Nothing = 0,
    /// @brief  Decode the header
    TransportDecodeLevel_Header = 1,
    /// @brief Decode the header and the raw payload as hexadecimal
    TransportDecodeLevel_Payload = 2,
} transport_decode_level_t;

static const char* TransportDecodeLevel_to_string(transport_decode_level_t value)
{
    switch (value)
    {
        case TransportDecodeLevel_Nothing: return "Nothing";
        case TransportDecodeLevel_Header: return "Header";
        case TransportDecodeLevel_Payload: return "Payload";
        default: return "";
    }
}

/// @brief Controls how transmitted and received link frames are decoded at the INFO log level
typedef enum link_decode_level_t
{
    /// @brief Decode nothing
    LinkDecodeLevel_Nothing = 0,
    /// @brief  Decode the header
    LinkDecodeLevel_Header = 1,
    /// @brief Decode the header and the raw payload as hexadecimal
    LinkDecodeLevel_Payload = 2,
} link_decode_level_t;

static const char* LinkDecodeLevel_to_string(link_decode_level_t value)
{
    switch (value)
    {
        case LinkDecodeLevel_Nothing: return "Nothing";
        case LinkDecodeLevel_Header: return "Header";
        case LinkDecodeLevel_Payload: return "Payload";
        default: return "";
    }
}

/// @brief Controls how data transmitted at the physical layer (TCP, serial, etc) is logged
typedef enum phys_decode_level_t
{
    /// @brief Log nothing
    PhysDecodeLevel_Nothing = 0,
    /// @brief Log only the length of data that is sent and received
    PhysDecodeLevel_Length = 1,
    /// @brief Log the length and the actual data that is sent and received
    PhysDecodeLevel_Data = 2,
} phys_decode_level_t;

static const char* PhysDecodeLevel_to_string(phys_decode_level_t value)
{
    switch (value)
    {
        case PhysDecodeLevel_Nothing: return "Nothing";
        case PhysDecodeLevel_Length: return "Length";
        case PhysDecodeLevel_Data: return "Data";
        default: return "";
    }
}

typedef struct decode_level_t decode_level_t;

/// @brief Controls the decoding of transmitted and received data at the application, transport, link, and physical layers
typedef struct decode_level_t
{
    /// @brief Controls application fragment decoding
    /// @note Default value is @ref AppDecodeLevel_Nothing
    app_decode_level_t application;
    /// @brief Controls transport segment layer decoding
    /// @note Default value is @ref TransportDecodeLevel_Nothing
    transport_decode_level_t transport;
    /// @brief Controls link frame decoding
    /// @note Default value is @ref LinkDecodeLevel_Nothing
    link_decode_level_t link;
    /// @brief Controls the logging of physical layer read/write
    /// @note Default value is @ref PhysDecodeLevel_Nothing
    phys_decode_level_t physical;
} decode_level_t;

static decode_level_t decode_level_init()
{
    return (decode_level_t)
    {
        .application = AppDecodeLevel_Nothing,
        .transport = TransportDecodeLevel_Nothing,
        .link = LinkDecodeLevel_Nothing,
        .physical = PhysDecodeLevel_Nothing,
    };
}

typedef struct retry_strategy_t retry_strategy_t;

/// @brief Retry strategy configuration.
/// 
/// The strategy uses an exponential back-off with a minimum and maximum value.
typedef struct retry_strategy_t
{
    /// @brief Minimum delay between two retries
    /// @note Default value is 1s
    uint64_t min_delay;
    /// @brief Maximum delay between two retries
    /// @note Default value is 10s
    uint64_t max_delay;
} retry_strategy_t;

static retry_strategy_t retry_strategy_init()
{
    return (retry_strategy_t)
    {
        .min_delay = 1000,
        .max_delay = 10000,
    };
}

/// @brief Number of bits per character
typedef enum data_bits_t
{
    /// @brief 5 bits per character
    DataBits_Five = 0,
    /// @brief 6 bits per character
    DataBits_Six = 1,
    /// @brief 7 bits per character
    DataBits_Seven = 2,
    /// @brief 8 bits per character
    DataBits_Eight = 3,
} data_bits_t;

static const char* DataBits_to_string(data_bits_t value)
{
    switch (value)
    {
        case DataBits_Five: return "Five";
        case DataBits_Six: return "Six";
        case DataBits_Seven: return "Seven";
        case DataBits_Eight: return "Eight";
        default: return "";
    }
}

/// @brief Flow control modes
typedef enum flow_control_t
{
    /// @brief No flow control
    FlowControl_None = 0,
    /// @brief Flow control using XON/XOFF bytes
    FlowControl_Software = 1,
    /// @brief Flow control using RTS/CTS signals
    FlowControl_Hardware = 2,
} flow_control_t;

static const char* FlowControl_to_string(flow_control_t value)
{
    switch (value)
    {
        case FlowControl_None: return "None";
        case FlowControl_Software: return "Software";
        case FlowControl_Hardware: return "Hardware";
        default: return "";
    }
}

/// @brief Parity checking modes
typedef enum parity_t
{
    /// @brief No parity bit
    Parity_None = 0,
    /// @brief Parity bit sets odd number of 1 bits
    Parity_Odd = 1,
    /// @brief Parity bit sets even number of 1 bits
    Parity_Even = 2,
} parity_t;

static const char* Parity_to_string(parity_t value)
{
    switch (value)
    {
        case Parity_None: return "None";
        case Parity_Odd: return "Odd";
        case Parity_Even: return "Even";
        default: return "";
    }
}

/// @brief Number of stop bits
typedef enum stop_bits_t
{
    /// @brief One stop bit
    StopBits_One = 0,
    /// @brief Two stop bits
    StopBits_Two = 1,
} stop_bits_t;

static const char* StopBits_to_string(stop_bits_t value)
{
    switch (value)
    {
        case StopBits_One: return "One";
        case StopBits_Two: return "Two";
        default: return "";
    }
}

typedef struct serial_port_settings_t serial_port_settings_t;

/// @brief Serial port settings
typedef struct serial_port_settings_t
{
    /// @brief Baud rate (in symbols-per-second)
    /// @note Default value is 9600
    uint32_t baud_rate;
    /// @brief Number of bits used to represent a character sent on the line
    /// @note Default value is @ref DataBits_Eight
    data_bits_t data_bits;
    /// @brief Type of signalling to use for controlling data transfer
    /// @note Default value is @ref FlowControl_None
    flow_control_t flow_control;
    /// @brief Type of parity to use for error checking
    /// @note Default value is @ref Parity_None
    parity_t parity;
    /// @brief Number of bits to use to signal the end of a character
    /// @note Default value is @ref StopBits_One
    stop_bits_t stop_bits;
} serial_port_settings_t;

static serial_port_settings_t serial_port_settings_init()
{
    return (serial_port_settings_t)
    {
        .baud_rate = 9600,
        .data_bits = DataBits_Eight,
        .flow_control = FlowControl_None,
        .parity = Parity_None,
        .stop_bits = StopBits_One,
    };
}

/// @brief Controls how errors in parsed link-layer frames are handled. This behavior is configurable for physical layers with built-in error correction like TCP as the connection might be through a terminal server.
typedef enum link_error_mode_t
{
    /// @brief Framing errors are discarded. The link-layer parser is reset on any error, and the parser begins scanning for 0x0564. This is always the behavior for serial ports.
    LinkErrorMode_Discard = 0,
    /// @brief Framing errors are bubbled up to calling code, closing the session. Suitable for physical layers that provide error correction like TCP.
    LinkErrorMode_Close = 1,
} link_error_mode_t;

static const char* LinkErrorMode_to_string(link_error_mode_t value)
{
    switch (value)
    {
        case LinkErrorMode_Discard: return "Discard";
        case LinkErrorMode_Close: return "Close";
        default: return "";
    }
}

/// @brief Type of response
typedef enum response_function_t
{
    /// @brief Solicited response
    ResponseFunction_Response = 0,
    /// @brief Unsolicited response
    ResponseFunction_UnsolicitedResponse = 1,
} response_function_t;

static const char* ResponseFunction_to_string(response_function_t value)
{
    switch (value)
    {
        case ResponseFunction_Response: return "Response";
        case ResponseFunction_UnsolicitedResponse: return "UnsolicitedResponse";
        default: return "";
    }
}

typedef struct iin1_t iin1_t;

/// @brief First IIN byte
typedef struct iin1_t
{
    /// @brief Byte value
    uint8_t value;
} iin1_t;

static iin1_t iin1_init(uint8_t value)
{
    return (iin1_t)
    {
        .value = value,
    };
}

/// @brief First IIN bit flags
typedef enum iin1_flag_t
{
    /// @brief Indicate that the message was broadcasted
    Iin1Flag_Broadcast = 0,
    /// @brief Outstation has Class 1 events not reported yet
    Iin1Flag_Class1Events = 1,
    /// @brief Outstation has Class 2 events not reported yet
    Iin1Flag_Class2Events = 2,
    /// @brief Outstation has Class 3 events not reported yet
    Iin1Flag_Class3Events = 3,
    /// @brief Outstation indicates it requires time synchronization from the master
    Iin1Flag_NeedTime = 4,
    /// @brief At least one point of the outstation is in the local operation mode
    Iin1Flag_LocalControl = 5,
    /// @brief Outstation reports abnormal condition
    Iin1Flag_DeviceTrouble = 6,
    /// @brief Outstation has restarted
    Iin1Flag_DeviceRestart = 7,
} iin1_flag_t;

static const char* IIN1Flag_to_string(iin1_flag_t value)
{
    switch (value)
    {
        case Iin1Flag_Broadcast: return "Broadcast";
        case Iin1Flag_Class1Events: return "Class1Events";
        case Iin1Flag_Class2Events: return "Class2Events";
        case Iin1Flag_Class3Events: return "Class3Events";
        case Iin1Flag_NeedTime: return "NeedTime";
        case Iin1Flag_LocalControl: return "LocalControl";
        case Iin1Flag_DeviceTrouble: return "DeviceTrouble";
        case Iin1Flag_DeviceRestart: return "DeviceRestart";
        default: return "";
    }
}

/// @brief Check if a particular flag is set in the IIN1 byte
/// @param iin1 IIN1 to check
/// @param flag Flag to check
/// @return true if the flag is set, false otherwise
bool iin1_is_set(iin1_t* iin1, iin1_flag_t flag);


typedef struct iin2_t iin2_t;

/// @brief Second IIN byte
typedef struct iin2_t
{
    /// @brief Byte value
    uint8_t value;
} iin2_t;

static iin2_t iin2_init(uint8_t value)
{
    return (iin2_t)
    {
        .value = value,
    };
}

/// @brief Second IIN bit flags
typedef enum iin2_flag_t
{
    /// @brief Function code is not supported by the outstation
    Iin2Flag_NoFuncCodeSupport = 0,
    /// @brief Request contains an unknown point
    Iin2Flag_ObjectUnknown = 1,
    /// @brief Unable to parse request or invalid qualifier code
    Iin2Flag_ParameterError = 2,
    /// @brief Event buffer overflow, at least one event was lost
    Iin2Flag_EventBufferOverflow = 3,
    /// @brief Cannot perform operation because an execution is already in progress
    Iin2Flag_AlreadyExecuting = 4,
    /// @brief Outstation reports a configuration corruption
    Iin2Flag_ConfigCorrupt = 5,
} iin2_flag_t;

static const char* IIN2Flag_to_string(iin2_flag_t value)
{
    switch (value)
    {
        case Iin2Flag_NoFuncCodeSupport: return "NoFuncCodeSupport";
        case Iin2Flag_ObjectUnknown: return "ObjectUnknown";
        case Iin2Flag_ParameterError: return "ParameterError";
        case Iin2Flag_EventBufferOverflow: return "EventBufferOverflow";
        case Iin2Flag_AlreadyExecuting: return "AlreadyExecuting";
        case Iin2Flag_ConfigCorrupt: return "ConfigCorrupt";
        default: return "";
    }
}

/// @brief Check if a particular flag is set in the IIN2 byte
/// @param iin2 IIN2 to check
/// @param flag Flag to check
/// @return true if the flag is set, false otherwise
bool iin2_is_set(iin2_t* iin2, iin2_flag_t flag);


typedef struct iin_t iin_t;

/// @brief Pair of IIN bytes
typedef struct iin_t
{
    /// @brief First IIN byte
    iin1_t iin1;
    /// @brief Second IIN byte
    iin2_t iin2;
} iin_t;

static iin_t iin_init(iin1_t iin1, iin2_t iin2)
{
    return (iin_t)
    {
        .iin1 = iin1,
        .iin2 = iin2,
    };
}

typedef struct response_header_t response_header_t;

/// @brief Response header information
typedef struct response_header_t
{
    /// @brief Application control field
    control_t control;
    /// @brief Response type
    response_function_t func;
    /// @brief IIN bytes
    iin_t iin;
} response_header_t;

static response_header_t response_header_init(control_t control, response_function_t func, iin_t iin)
{
    return (response_header_t)
    {
        .control = control,
        .func = func,
        .iin = iin,
    };
}

/// @brief Qualifier code used in the response
typedef enum qualifier_code_t
{
    /// @brief 8-bit start stop (0x00)
    QualifierCode_Range8 = 0,
    /// @brief 16-bit start stop (0x01)
    QualifierCode_Range16 = 1,
    /// @brief All objects (0x06)
    QualifierCode_AllObjects = 2,
    /// @brief 8-bit count (0x07)
    QualifierCode_Count8 = 3,
    /// @brief 16-bit count (0x08)
    QualifierCode_Count16 = 4,
    /// @brief 8-bit count and prefix (0x17)
    QualifierCode_CountAndPrefix8 = 5,
    /// @brief 16-bit count and prefix (0x28)
    QualifierCode_CountAndPrefix16 = 6,
    /// @brief 16-bit free format (0x5B)
    QualifierCode_FreeFormat16 = 7,
} qualifier_code_t;

static const char* QualifierCode_to_string(qualifier_code_t value)
{
    switch (value)
    {
        case QualifierCode_Range8: return "Range8";
        case QualifierCode_Range16: return "Range16";
        case QualifierCode_AllObjects: return "AllObjects";
        case QualifierCode_Count8: return "Count8";
        case QualifierCode_Count16: return "Count16";
        case QualifierCode_CountAndPrefix8: return "CountAndPrefix8";
        case QualifierCode_CountAndPrefix16: return "CountAndPrefix16";
        case QualifierCode_FreeFormat16: return "FreeFormat16";
        default: return "";
    }
}

typedef struct header_info_t header_info_t;

/// @brief Object header information
typedef struct header_info_t
{
    /// @brief Group/Variation used in the response
    variation_t variation;
    /// @brief Qualitifer used in the response
    qualifier_code_t qualifier;
} header_info_t;

static header_info_t header_info_init(variation_t variation, qualifier_code_t qualifier)
{
    return (header_info_t)
    {
        .variation = variation,
        .qualifier = qualifier,
    };
}

typedef struct byte_t byte_t;

/// @brief Single byte struct
typedef struct byte_t
{
    /// @brief Byte value
    uint8_t value;
} byte_t;

static byte_t byte_init(uint8_t value)
{
    return (byte_t)
    {
        .value = value,
    };
}

/// @brief Iterator of @ref byte_t. See @ref byte_next.
typedef struct byte_iterator_t byte_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
byte_t* byte_next(byte_iterator_t* it);


typedef struct octet_string_t octet_string_t;

/// @brief Octet String point
typedef struct octet_string_t
{
    /// @brief Point index
    uint16_t index;
    /// @brief Point value
    byte_iterator_t* value;
} octet_string_t;

static octet_string_t octet_string_init(uint16_t index, byte_iterator_t* value)
{
    return (octet_string_t)
    {
        .index = index,
        .value = value,
    };
}

/// @brief Iterator of @ref octet_string_t. See @ref octetstring_next.
typedef struct octet_string_iterator_t octet_string_iterator_t;

/// @brief Get the next value of the iterator
/// @param it Iterator
/// @return Next value of the iterator or @p NULL if the iterator reached the end
octet_string_t* octetstring_next(octet_string_iterator_t* it);


/// @brief General handler that will receive all values read from the outstation.
typedef struct read_handler_t
{
    
    /// @brief Marks the beginning of a fragment
    /// @param header Header of the fragment
    /// @param ctx Context data
    void (*begin_fragment)(response_header_t, void*);
    
    /// @brief Marks the end of a fragment
    /// @param header Header of the fragment
    /// @param ctx Context data
    void (*end_fragment)(response_header_t, void*);
    
    /// @brief Handle binary input data
    /// @param info Group/variation and qualifier information
    /// @param it Iterator of point values in the response. This iterator is valid only within this call. Do not copy it.
    /// @param ctx Context data
    void (*handle_binary)(header_info_t, binary_iterator_t*, void*);
    
    /// @brief Handle double-bit binary input data
    /// @param info Group/variation and qualifier information
    /// @param it Iterator of point values in the response. This iterator is valid only within this call. Do not copy it.
    /// @param ctx Context data
    void (*handle_double_bit_binary)(header_info_t, double_bit_binary_iterator_t*, void*);
    
    /// @brief Handle binary output status data
    /// @param info Group/variation and qualifier information
    /// @param it Iterator of point values in the response. This iterator is valid only within this call. Do not copy it.
    /// @param ctx Context data
    void (*handle_binary_output_status)(header_info_t, binary_output_status_iterator_t*, void*);
    
    /// @brief Handle counter data
    /// @param info Group/variation and qualifier information
    /// @param it Iterator of point values in the response. This iterator is valid only within this call. Do not copy it.
    /// @param ctx Context data
    void (*handle_counter)(header_info_t, counter_iterator_t*, void*);
    
    /// @brief Handle frozen counter input data
    /// @param info Group/variation and qualifier information
    /// @param it Iterator of point values in the response. This iterator is valid only within this call. Do not copy it.
    /// @param ctx Context data
    void (*handle_frozen_counter)(header_info_t, frozen_counter_iterator_t*, void*);
    
    /// @brief Handle analog input data
    /// @param info Group/variation and qualifier information
    /// @param it Iterator of point values in the response. This iterator is valid only within this call. Do not copy it.
    /// @param ctx Context data
    void (*handle_analog)(header_info_t, analog_iterator_t*, void*);
    
    /// @brief Handle analog output status data
    /// @param info Group/variation and qualifier information
    /// @param it Iterator of point values in the response. This iterator is valid only within this call. Do not copy it.
    /// @param ctx Context data
    void (*handle_analog_output_status)(header_info_t, analog_output_status_iterator_t*, void*);
    
    /// @brief Handle octet string data
    /// @param info Group/variation and qualifier information
    /// @param it Iterator of point values in the response. This iterator is valid only within this call. Do not copy it.
    /// @param ctx Context data
    void (*handle_octet_string)(header_info_t, octet_string_iterator_t*, void*);
    /// @brief Callback when the underlying owner doesn't need the callback anymore
    /// @param arg Context data
    void (*on_destroy)(void* arg);
    /// @brief Context data
    void* ctx;
} read_handler_t;

/// @brief List of IP endpoints.
/// 
/// You can write IP addresses or DNS names and the port to connect to. e.g. "127.0.0.1:20000" or "dnp3.myorg.com:20000".
typedef struct endpoint_list_t endpoint_list_t;

/// @brief Create a new list of IP endpoints.
/// 
/// You can write IP addresses or DNS names and the port to connect to. e.g. "127.0.0.1:20000" or "dnp3.myorg.com:20000".
/// @param main_endpoint Main endpoint
/// @return New endpoint list
endpoint_list_t* endpoint_list_new(const char* main_endpoint);

/// @brief Delete a previously allocated endpoint list.
/// @param list Endpoint list to destroy
void endpoint_list_destroy(endpoint_list_t* list);

/// @brief .
/// 
/// You can write IP addresses or DNS names and the port to connect to. e.g. "127.0.0.1:20000" or "dnp3.myorg.com:20000".
/// @param list Endpoint list to modify
/// @param endpoint Endpoint to add to the list
void endpoint_list_add(endpoint_list_t* list, const char* endpoint);


typedef struct master_config_t master_config_t;

/// @brief Master configuration
typedef struct master_config_t
{
    /// @brief Local DNP3 data-link address
    uint16_t address;
    /// @brief Decoding level for this master. You can modify this later on with @ref master_set_decode_level.
    decode_level_t decode_level;
    /// @brief Timeout for receiving a response
    /// @note Default value is 5s
    uint64_t response_timeout;
    /// @brief TX buffer size
    /// 
    /// Should be at least 249
    /// @note Default value is 2048
    uint16_t tx_buffer_size;
    /// @brief RX buffer size
    /// 
    /// Should be at least 2048
    /// @note Default value is 2048
    uint16_t rx_buffer_size;
} master_config_t;

static master_config_t master_config_init(uint16_t address)
{
    return (master_config_t)
    {
        .address = address,
        .decode_level = decode_level_init(),
        .response_timeout = 5000,
        .tx_buffer_size = 2048,
        .rx_buffer_size = 2048,
    };
}

/// @brief State of the client connection.
/// 
/// Use by the @ref client_state_listener_t.
typedef enum client_state_t
{
    /// @brief Client is disabled and idle until disabled
    ClientState_Disabled = 0,
    /// @brief Client is trying to establish a connection to the remote device
    ClientState_Connecting = 1,
    /// @brief Client is connected to the remote device
    ClientState_Connected = 2,
    /// @brief Failed to establish a connection, waiting before retrying
    ClientState_WaitAfterFailedConnect = 3,
    /// @brief Client was disconnected, waiting before retrying
    ClientState_WaitAfterDisconnect = 4,
    /// @brief Client is shutting down
    ClientState_Shutdown = 5,
} client_state_t;

static const char* ClientState_to_string(client_state_t value)
{
    switch (value)
    {
        case ClientState_Disabled: return "Disabled";
        case ClientState_Connecting: return "Connecting";
        case ClientState_Connected: return "Connected";
        case ClientState_WaitAfterFailedConnect: return "WaitAfterFailedConnect";
        case ClientState_WaitAfterDisconnect: return "WaitAfterDisconnect";
        case ClientState_Shutdown: return "Shutdown";
        default: return "";
    }
}

/// @brief Callback for monitoring the client TCP connection state
typedef struct client_state_listener_t
{
    
    /// @brief Called when the client state changed
    /// @param state New state
    /// @param ctx Context data
    void (*on_change)(client_state_t, void*);
    /// @brief Callback when the underlying owner doesn't need the callback anymore
    /// @param arg Context data
    void (*on_destroy)(void* arg);
    /// @brief Context data
    void* ctx;
} client_state_listener_t;

/// @brief Master channel of communication
/// 
/// To communicate with a particular outstation, you need to add an association with @ref master_add_association.
/// 
/// @warning This cannot be called from within a callback.
typedef struct master_t master_t;

/// @brief Create a master TCP session connecting to the specified endpoint(s)
/// 
/// The returned master must be gracefully shutdown with @ref master_destroy when done.
/// @param runtime Runtime to use to drive asynchronous operations of the master
/// @param link_error_mode Controls how link errors are handled with respect to the TCP session
/// @param config Master configuration
/// @param endpoints List of IP endpoints.
/// @param connect_strategy Connection retry strategy to use
/// @param reconnect_delay delay before reconnecting after a disconnect
/// @param listener TCP connection listener used to receive updates on the status of the connection
/// @return Handle to the master created, @p NULL if an error occurred
master_t* master_create_tcp_session(runtime_t* runtime, link_error_mode_t link_error_mode, master_config_t config, endpoint_list_t* endpoints, retry_strategy_t connect_strategy, uint64_t reconnect_delay, client_state_listener_t listener);

/// @brief Create a master session on the specified serial port
/// 
/// The returned master must be gracefully shutdown with @ref master_destroy when done.
/// @param runtime Runtime to use to drive asynchronous operations of the master
/// @param config Master configuration
/// @param path Path to the serial device. Generally /dev/tty0 on Linux and COM1 on Windows.
/// @param serial_params Serial port settings
/// @param open_retry_delay delay between attempts to open the serial port
/// @param listener Listener to receive updates on the status of the serial port
/// @return Handle to the master created, @p NULL if an error occurred
master_t* master_create_serial_session(runtime_t* runtime, master_config_t config, const char* path, serial_port_settings_t serial_params, uint64_t open_retry_delay, port_state_listener_t listener);

/// @brief Remove and destroy a master.
/// 
/// @warning This method must NOT be called from within the @ref runtime_t thread.
/// @param master Master to destroy
void master_destroy(master_t* master);

/// @brief start communications
/// @param master master to enable
void master_enable(master_t* master);

/// @brief stop communications
/// @param master master to disable
void master_disable(master_t* master);

/// @brief Master-outstation association to interact with
typedef struct association_t association_t;

/// @brief Remove an association
/// 
/// This method will gracefully end all communications with this particular outstation.
/// @param association Association to destroy
void association_destroy(association_t* association);

/// @brief Poll handle to demand executions of polls with @ref poll_demand.
typedef struct poll_t poll_t;

/// @brief Demand the immediate execution of a poll previously created with @ref association_add_poll.
/// 
/// This method returns immediatly. The result will be sent to the registered @ref read_handler_t.
/// 
/// This method resets the internal timer of the poll.
/// @param poll Poll handle to demand
void poll_demand(poll_t* poll);

/// @brief Remove a poll. The poll won't be performed again.
/// @param poll Poll handle to destroy
void poll_destroy(poll_t* poll);


/// @brief Custom request
/// 
/// Whenever a method takes a request as a parameter, the request is internally copied. Therefore, it is possible to reuse the same requests over and over.
typedef struct request_t request_t;

/// @brief Create a new request
/// @return Handle to the created request
request_t* request_new();

/// @brief Create a new request asking for classes
/// 
/// An identical request can be created manually with @ref request_add_all_objects_header and variations @ref Variation_Group60Var1, @ref Variation_Group60Var2, @ref Variation_Group60Var3 and @ref Variation_Group60Var4.
/// @param class0 Ask for class 0 (static data)
/// @param class1 Ask for class 1 events
/// @param class2 Ask for class 2 events
/// @param class3 Ask for class 3 events
/// @return Handle to the created request
request_t* request_new_class(bool class0, bool class1, bool class2, bool class3);

/// @brief Destroy a request created with @ref request_new or @ref request_new_class.
/// @param request Request to destroy
void request_destroy(request_t* request);

/// @brief Add a one-byte start/stop variation interrogation
/// @param request Request to modify
/// @param variation Variation to ask for
/// @param start Start index to ask
/// @param stop Stop index to ask (inclusive)
void request_add_one_byte_header(request_t* request, variation_t variation, uint8_t start, uint8_t stop);

/// @brief Add a two-byte start/stop variation interrogation
/// @param request Request to modify
/// @param variation Variation to ask for
/// @param start Start index to ask
/// @param stop Stop index to ask (inclusive)
void request_add_two_byte_header(request_t* request, variation_t variation, uint16_t start, uint16_t stop);

/// @brief Add an all objects variation interrogation
/// @param request Request to modify
/// @param variation Variation to ask for
void request_add_all_objects_header(request_t* request, variation_t variation);


/// @brief Add a periodic poll to the association.
/// 
/// Each result of the poll will be sent to the @ref read_handler_t of the association.
/// 
/// @warning This cannot be called from within a callback.
/// @param association Association to add the poll to
/// @param request Request to perform
/// @param period Period to wait between each poll (in ms)
/// @return Handle to the created poll.
poll_t* association_add_poll(association_t* association, request_t* request, uint64_t period);

/// @brief Result of a read operation
typedef enum read_result_t
{
    /// @brief Read was perform successfully
    ReadResult_Success = 0,
    /// @brief The read was not performed properly
    ReadResult_TaskError = 1,
} read_result_t;

static const char* ReadResult_to_string(read_result_t value)
{
    switch (value)
    {
        case ReadResult_Success: return "Success";
        case ReadResult_TaskError: return "TaskError";
        default: return "";
    }
}

/// @brief Handler for read tasks
typedef struct read_task_callback_t
{
    
    /// @brief Called when the read task reached completion or failed
    /// @param result Result of the read task
    /// @param ctx Context data
    void (*on_complete)(read_result_t, void*);
    /// @brief Context data
    void* ctx;
} read_task_callback_t;

/// @brief Perform a read on the association.
/// 
/// The callback will be called once the read is completely received, but the actual values will be sent to the @ref read_handler_t of the association.
/// @param association Association to read
/// @param request Request to send
/// @param callback Callback that will be called once the read is complete
void association_read(association_t* association, request_t* request, read_task_callback_t callback);

/// @brief Command operation mode
typedef enum command_mode_t
{
    /// @brief Perform a Direct Operate (0x05)
    CommandMode_DirectOperate = 0,
    /// @brief Perform a Select & Operate (0x03 then 0x04)
    CommandMode_SelectBeforeOperate = 1,
} command_mode_t;

static const char* CommandMode_to_string(command_mode_t value)
{
    switch (value)
    {
        case CommandMode_DirectOperate: return "DirectOperate";
        case CommandMode_SelectBeforeOperate: return "SelectBeforeOperate";
        default: return "";
    }
}

/// @brief Command handle used to send SBO or DO commands
typedef struct command_t command_t;

/// @brief Create a new command
/// @return Handle to the created command
command_t* command_new();

/// @brief Destroy command
/// @param command Command to destroy
void command_destroy(command_t* command);

/// @brief Add a CROB with 1-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param header CROB data
void command_add_u8_g12v1(command_t* command, uint8_t idx, g12v1_t header);

/// @brief Add a CROB with 2-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param header CROB data
void command_add_u16_g12v1(command_t* command, uint16_t idx, g12v1_t header);

/// @brief Add a Analog Output command (signed 32-bit integer) with 1-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param value Value to set the analog output to
void command_add_u8_g41v1(command_t* command, uint8_t idx, int32_t value);

/// @brief Add a Analog Output command (signed 32-bit integer) with 2-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param value Value to set the analog output to
void command_add_u16_g41v1(command_t* command, uint16_t idx, int32_t value);

/// @brief Add a Analog Output command (signed 16-bit integer) with 1-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param value Value to set the analog output to
void command_add_u8_g41v2(command_t* command, uint8_t idx, int16_t value);

/// @brief Add a Analog Output command (signed 16-bit integer) with 2-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param value Value to set the analog output to
void command_add_u16_g41v2(command_t* command, uint16_t idx, int16_t value);

/// @brief Add a Analog Output command (single-precision float) with 1-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param value Value to set the analog output to
void command_add_u8_g41v3(command_t* command, uint8_t idx, float value);

/// @brief Add a Analog Output command (single-precision float) with 2-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param value Value to set the analog output to
void command_add_u16_g41v3(command_t* command, uint16_t idx, float value);

/// @brief Add a Analog Output command (double-precision float) with 1-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param value Value to set the analog output to
void command_add_u8_g41v4(command_t* command, uint8_t idx, double value);

/// @brief Add a Analog Output command (double-precision float) with 2-byte prefix index
/// @param command Command to modify
/// @param idx Index of the point to send the command to
/// @param value Value to set the analog output to
void command_add_u16_g41v4(command_t* command, uint16_t idx, double value);


/// @brief Result of a command
typedef enum command_result_t
{
    /// @brief Command was a success
    CommandResult_Success = 0,
    /// @brief Failed b/c of a generic task execution error
    CommandResult_TaskError = 1,
    /// @brief Outstation indicated that a command was not SUCCESS
    CommandResult_BadStatus = 2,
    /// @brief Number of headers in the response doesn't match the number in the request
    CommandResult_HeaderCountMismatch = 3,
    /// @brief Header in the response doesn't match the request
    CommandResult_HeaderTypeMismatch = 4,
    /// @brief Number of objects in one of the headers doesn't match the request
    CommandResult_ObjectCountMismatch = 5,
    /// @brief Value in one of the objects in the response doesn't match the request
    CommandResult_ObjectValueMismatch = 6,
} command_result_t;

static const char* CommandResult_to_string(command_result_t value)
{
    switch (value)
    {
        case CommandResult_Success: return "Success";
        case CommandResult_TaskError: return "TaskError";
        case CommandResult_BadStatus: return "BadStatus";
        case CommandResult_HeaderCountMismatch: return "HeaderCountMismatch";
        case CommandResult_HeaderTypeMismatch: return "HeaderTypeMismatch";
        case CommandResult_ObjectCountMismatch: return "ObjectCountMismatch";
        case CommandResult_ObjectValueMismatch: return "ObjectValueMismatch";
        default: return "";
    }
}

/// @brief Handler for command tasks
typedef struct command_task_callback_t
{
    
    /// @brief Called when the command task reached completion or failed
    /// @param result Result of the command task
    /// @param ctx Context data
    void (*on_complete)(command_result_t, void*);
    /// @brief Context data
    void* ctx;
} command_task_callback_t;

/// @brief Asynchronously send a command to the association
/// @param association Association to send the command to
/// @param mode Operation mode
/// @param command Command to send
/// @param callback Callback that will receive the result of the command
void association_operate(association_t* association, command_mode_t mode, command_t* command, command_task_callback_t callback);

/// @brief Time synchronization mode
typedef enum time_sync_mode_t
{
    /// @brief Perform a LAN time sync with Record Current Time (0x18) function code
    TimeSyncMode_Lan = 0,
    /// @brief Perform a non-LAN time sync with Delay Measurement (0x17) function code
    TimeSyncMode_NonLan = 1,
} time_sync_mode_t;

static const char* TimeSyncMode_to_string(time_sync_mode_t value)
{
    switch (value)
    {
        case TimeSyncMode_Lan: return "Lan";
        case TimeSyncMode_NonLan: return "NonLan";
        default: return "";
    }
}

/// @brief Result of a time sync operation
typedef enum time_sync_result_t
{
    /// @brief Time synchronization operation was a success
    TimeSyncResult_Success = 0,
    /// @brief Failed b/c of a generic task execution error
    TimeSyncResult_TaskError = 1,
    /// @brief Detected a clock rollback
    TimeSyncResult_ClockRollback = 2,
    /// @brief The system time cannot be converted to a Unix timestamp
    TimeSyncResult_SystemTimeNotUnix = 3,
    /// @brief Outstation time delay exceeded the response delay
    TimeSyncResult_BadOutstationTimeDelay = 4,
    /// @brief Overflow in calculation
    TimeSyncResult_Overflow = 5,
    /// @brief Outstation did not clear the NEED_TIME IIN bit
    TimeSyncResult_StillNeedsTime = 6,
    /// @brief System time not available
    TimeSyncResult_SystemTimeNotAvailable = 7,
    /// @brief Outstation indicated an error
    TimeSyncResult_IinError = 8,
} time_sync_result_t;

static const char* TimeSyncResult_to_string(time_sync_result_t value)
{
    switch (value)
    {
        case TimeSyncResult_Success: return "Success";
        case TimeSyncResult_TaskError: return "TaskError";
        case TimeSyncResult_ClockRollback: return "ClockRollback";
        case TimeSyncResult_SystemTimeNotUnix: return "SystemTimeNotUnix";
        case TimeSyncResult_BadOutstationTimeDelay: return "BadOutstationTimeDelay";
        case TimeSyncResult_Overflow: return "Overflow";
        case TimeSyncResult_StillNeedsTime: return "StillNeedsTime";
        case TimeSyncResult_SystemTimeNotAvailable: return "SystemTimeNotAvailable";
        case TimeSyncResult_IinError: return "IinError";
        default: return "";
    }
}

/// @brief Handler for time synchronization tasks
typedef struct time_sync_task_callback_t
{
    
    /// @brief Called when the timesync task reached completion or failed
    /// @param result Result of the time synchronization task
    /// @param ctx Context data
    void (*on_complete)(time_sync_result_t, void*);
    /// @brief Context data
    void* ctx;
} time_sync_task_callback_t;

/// @brief Asynchronously perform a timesync operation to the association
/// @param association Association to perform the timesync to
/// @param mode Timesync mode
/// @param callback Callback that will receive the result of the timesync
void association_perform_time_sync(association_t* association, time_sync_mode_t mode, time_sync_task_callback_t callback);

/// @brief Result of a read operation
typedef enum restart_success_t
{
    /// @brief Restart was perform successfully
    RestartSuccess_Success = 0,
    /// @brief The restart was not performed properly
    RestartSuccess_TaskError = 1,
} restart_success_t;

static const char* RestartSuccess_to_string(restart_success_t value)
{
    switch (value)
    {
        case RestartSuccess_Success: return "Success";
        case RestartSuccess_TaskError: return "TaskError";
        default: return "";
    }
}

typedef struct restart_result_t restart_result_t;

/// @brief Result of a restart task
typedef struct restart_result_t
{
    /// @brief Delay value returned by the outstation. Valid only if @ref restart_result_t.success is @ref RestartSuccess_Success.
    uint64_t delay;
    /// @brief Success status of the restart task
    restart_success_t success;
} restart_result_t;

static restart_result_t restart_result_init(uint64_t delay, restart_success_t success)
{
    return (restart_result_t)
    {
        .delay = delay,
        .success = success,
    };
}

/// @brief Handler for restart tasks
typedef struct restart_task_callback_t
{
    
    /// @brief Called when the restart task reached completion or failed
    /// @param result Result of the restart task
    /// @param ctx Context data
    void (*on_complete)(restart_result_t, void*);
    /// @brief Context data
    void* ctx;
} restart_task_callback_t;

/// @brief Asynchronously perform a cold restart operation to the association
/// @param association Association to perform the cold restart
/// @param callback Callback that will receive the result of the restart
void association_cold_restart(association_t* association, restart_task_callback_t callback);

/// @brief Asynchronously perform a warm restart operation to the association
/// @param association Association to perform the warm restart
/// @param callback Callback that will receive the result of the restart
void association_warm_restart(association_t* association, restart_task_callback_t callback);

/// @brief Result of a link status check. See @ref association_check_link_status
typedef enum link_status_result_t
{
    /// @brief The outstation responded with a valid LINK_STATUS
    LinkStatusResult_Success = 0,
    /// @brief There was activity on the link, but it wasn't a LINK_STATUS
    LinkStatusResult_UnexpectedResponse = 1,
    /// @brief The task failed for some reason (e.g. the master was shutdown)
    LinkStatusResult_TaskError = 2,
} link_status_result_t;

static const char* LinkStatusResult_to_string(link_status_result_t value)
{
    switch (value)
    {
        case LinkStatusResult_Success: return "Success";
        case LinkStatusResult_UnexpectedResponse: return "UnexpectedResponse";
        case LinkStatusResult_TaskError: return "TaskError";
        default: return "";
    }
}

/// @brief Handler for link status check
typedef struct link_status_callback_t
{
    
    /// @brief Called when a link status is received
    /// @param result Result of the link status
    /// @param ctx Context data
    void (*on_complete)(link_status_result_t, void*);
    /// @brief Context data
    void* ctx;
} link_status_callback_t;

/// @brief Asynchronously perform a link status check
/// @param association Association to perform the link status check
/// @param callback Callback that will receive the result of the link status
void association_check_link_status(association_t* association, link_status_callback_t callback);


typedef struct event_classes_t event_classes_t;

/// @brief Event classes
typedef struct event_classes_t
{
    /// @brief Class 1 events
    bool class1;
    /// @brief Class 2 events
    bool class2;
    /// @brief Class 3 events
    bool class3;
} event_classes_t;

static event_classes_t event_classes_init(bool class1, bool class2, bool class3)
{
    return (event_classes_t)
    {
        .class1 = class1,
        .class2 = class2,
        .class3 = class3,
    };
}

/// @brief Initialize all three event classes to true
/// @return Initialized value
event_classes_t event_classes_all();

/// @brief Initialize all three event classes to false
/// @return Initialized value
event_classes_t event_classes_none();


typedef struct classes_t classes_t;

/// @brief Class 0, 1, 2 and 3 config
typedef struct classes_t
{
    /// @brief Class 0 (static data)
    bool class0;
    /// @brief Class 1 events
    bool class1;
    /// @brief Class 2 events
    bool class2;
    /// @brief Class 3 events
    bool class3;
} classes_t;

static classes_t classes_init(bool class0, bool class1, bool class2, bool class3)
{
    return (classes_t)
    {
        .class0 = class0,
        .class1 = class1,
        .class2 = class2,
        .class3 = class3,
    };
}

/// @brief Class 1230
/// @return Class 1230
classes_t classes_all();

/// @brief No class
/// @return No class
classes_t classes_none();


/// @brief Automatic time synchronization configuration
typedef enum auto_time_sync_t
{
    /// @brief Do not perform automatic time sync
    AutoTimeSync_None = 0,
    /// @brief Perform automatic time sync with Record Current Time (0x18) function code
    AutoTimeSync_Lan = 1,
    /// @brief Perform automatic time sync with Delay Measurement (0x17) function code
    AutoTimeSync_NonLan = 2,
} auto_time_sync_t;

static const char* AutoTimeSync_to_string(auto_time_sync_t value)
{
    switch (value)
    {
        case AutoTimeSync_None: return "None";
        case AutoTimeSync_Lan: return "Lan";
        case AutoTimeSync_NonLan: return "NonLan";
        default: return "";
    }
}

typedef struct association_config_t association_config_t;

/// @brief Association configuration
typedef struct association_config_t
{
    /// @brief Classes to disable unsolicited responses at startup
    event_classes_t disable_unsol_classes;
    /// @brief Classes to enable unsolicited responses at startup
    event_classes_t enable_unsol_classes;
    /// @brief Startup integrity classes to ask on master startup and when an outstation restart is detected.
    /// 
    /// For conformance, this should be Class 1230.
    classes_t startup_integrity_classes;
    /// @brief Automatic time synchronization configuration
    /// @note Default value is @ref AutoTimeSync_None
    auto_time_sync_t auto_time_sync;
    /// @brief Automatic tasks retry strategy
    retry_strategy_t auto_tasks_retry_strategy;
    /// @brief Delay of inactivity before sending a REQUEST_LINK_STATUS to the outstation
    /// 
    /// A value of zero means no automatic keep-alive.
    /// @note Default value is 60s
    uint64_t keep_alive_timeout;
    /// @brief Automatic integrity scan when an EVENT_BUFFER_OVERFLOW is detected
    /// @note Default value is true
    bool auto_integrity_scan_on_buffer_overflow;
    /// @brief Classes to automatically send reads when the IIN bit is asserted
    event_classes_t event_scan_on_events_available;
} association_config_t;

static association_config_t association_config_init(event_classes_t disable_unsol_classes, event_classes_t enable_unsol_classes, classes_t startup_integrity_classes, event_classes_t event_scan_on_events_available)
{
    return (association_config_t)
    {
        .disable_unsol_classes = disable_unsol_classes,
        .enable_unsol_classes = enable_unsol_classes,
        .startup_integrity_classes = startup_integrity_classes,
        .auto_time_sync = AutoTimeSync_None,
        .auto_tasks_retry_strategy = retry_strategy_init(),
        .keep_alive_timeout = 60,
        .auto_integrity_scan_on_buffer_overflow = true,
        .event_scan_on_events_available = event_scan_on_events_available,
    };
}

typedef struct association_handlers_t association_handlers_t;

/// @brief Handlers that will receive readings.
/// 
/// You can set all handlers to the same handler if knowing what type of event generated the value is not required.
typedef struct association_handlers_t
{
    /// @brief Handler for the initial integrity scan
    read_handler_t integrity_handler;
    /// @brief Handler for unsolicited responses
    read_handler_t unsolicited_handler;
    /// @brief Handler for all other responses
    read_handler_t default_poll_handler;
} association_handlers_t;

static association_handlers_t association_handlers_init(read_handler_t integrity_handler, read_handler_t unsolicited_handler, read_handler_t default_poll_handler)
{
    return (association_handlers_t)
    {
        .integrity_handler = integrity_handler,
        .unsolicited_handler = unsolicited_handler,
        .default_poll_handler = default_poll_handler,
    };
}

typedef struct time_provider_timestamp_t time_provider_timestamp_t;

/// @brief Timestamp value returned by @ref time_provider_t.
/// 
/// @ref time_provider_timestamp_t.value is only valid if @ref time_provider_timestamp_t.is_valid is true.
typedef struct time_provider_timestamp_t
{
    /// @brief Value of the timestamp (in milliseconds from UNIX Epoch).
    /// 
    /// @warning Only 48 bits are available for timestamps.
    uint64_t value;
    /// @brief True if the timestamp is valid, false otherwise.
    bool is_valid;
} time_provider_timestamp_t;

static time_provider_timestamp_t time_provider_timestamp_init(uint64_t value, bool is_valid)
{
    return (time_provider_timestamp_t)
    {
        .value = value,
        .is_valid = is_valid,
    };
}

/// @brief Create a valid timestamp value
/// @param value Timestamp value in milliseconds from UNIX Epoch
/// @return Timestamp
time_provider_timestamp_t timeprovidertimestamp_valid(uint64_t value);

/// @brief Create an invalid timestamp value
/// @return Timestamp
time_provider_timestamp_t timeprovidertimestamp_invalid();


/// @brief Current time provider
typedef struct time_provider_t
{
    
    /// @brief Returns the current time of the system.
    /// 
    /// This callback is called when time synchronization is performed.
    /// 
    /// This can use external clock synchronization or the system clock for example.
    /// @param ctx Context data
    /// @return The current time
    time_provider_timestamp_t (*get_time)(void*);
    /// @brief Callback when the underlying owner doesn't need the callback anymore
    /// @param arg Context data
    void (*on_destroy)(void* arg);
    /// @brief Context data
    void* ctx;
} time_provider_t;

/// @brief Add an association to the master
/// @param master Master to add the association to
/// @param address DNP3 data-link address of the remote outstation
/// @param config Association configuration
/// @param handlers Handlers to call when receiving point data
/// @param time_provider Time provider for the association
/// @return Handle to the created association or NULL if an error occurred
association_t* master_add_association(master_t* master, uint16_t address, association_config_t config, association_handlers_t handlers, time_provider_t time_provider);

/// @brief Set the master decoding level for log messages
/// @param master Master to modify
/// @param decode_level Decoding level
void master_set_decode_level(master_t* master, decode_level_t decode_level);

/// @brief Get the master decoding level for log messages
/// 
/// @warning This cannot be called from within a callback.
/// @param master @ref master_t to get the decode level from
/// @return Decode level
decode_level_t master_get_decode_level(master_t* master);


/// @brief Internal database access
/// 
/// @warning This object is only valid within the transaction.
typedef struct database_t database_t;

/// @brief Event class
typedef enum event_class_t
{
    /// @brief Does not generate events
    EventClass_None = 0,
    /// @brief Class 1 event
    EventClass_Class1 = 1,
    /// @brief Class 2 event
    EventClass_Class2 = 2,
    /// @brief Class 3 event
    EventClass_Class3 = 3,
} event_class_t;

static const char* EventClass_to_string(event_class_t value)
{
    switch (value)
    {
        case EventClass_None: return "None";
        case EventClass_Class1: return "Class1";
        case EventClass_Class2: return "Class2";
        case EventClass_Class3: return "Class3";
        default: return "";
    }
}

/// @brief Controls how events are processed when updating values in the database.
typedef enum event_mode_t
{
    /// @brief Detect events in a type dependent fashion
    /// 
    /// This is the default mode that should be used.
    EventMode_Detect = 0,
    /// @brief Produce an event whether the value has changed or not
    EventMode_Force = 1,
    /// @brief Never produce an event regardless of change
    EventMode_Suppress = 2,
} event_mode_t;

static const char* EventMode_to_string(event_mode_t value)
{
    switch (value)
    {
        case EventMode_Detect: return "Detect";
        case EventMode_Force: return "Force";
        case EventMode_Suppress: return "Suppress";
        default: return "";
    }
}

typedef struct update_options_t update_options_t;

/// @brief Options that control how the update is performed.
/// 
/// 99% of the time, the default value should be used.
typedef struct update_options_t
{
    /// @brief Optionnaly bypass updating the static database (the current value)
    /// @note Default value is true
    bool update_static;
    /// @brief Determines how/if an event is produced
    /// @note Default value is @ref EventMode_Detect
    event_mode_t event_mode;
} update_options_t;

static update_options_t update_options_init()
{
    return (update_options_t)
    {
        .update_static = true,
        .event_mode = EventMode_Detect,
    };
}

/// @brief Static binary input variation
typedef enum static_binary_variation_t
{
    /// @brief Binary input - packed format
    StaticBinaryVariation_Group1Var1 = 0,
    /// @brief Binary input - with flags
    StaticBinaryVariation_Group1Var2 = 1,
} static_binary_variation_t;

static const char* StaticBinaryVariation_to_string(static_binary_variation_t value)
{
    switch (value)
    {
        case StaticBinaryVariation_Group1Var1: return "Group1Var1";
        case StaticBinaryVariation_Group1Var2: return "Group1Var2";
        default: return "";
    }
}

/// @brief Event binary input variation
typedef enum event_binary_variation_t
{
    /// @brief Binary input event - without time
    EventBinaryVariation_Group2Var1 = 0,
    /// @brief Binary input event - with absolute time
    EventBinaryVariation_Group2Var2 = 1,
    /// @brief Binary input event - with relative time
    EventBinaryVariation_Group2Var3 = 2,
} event_binary_variation_t;

static const char* EventBinaryVariation_to_string(event_binary_variation_t value)
{
    switch (value)
    {
        case EventBinaryVariation_Group2Var1: return "Group2Var1";
        case EventBinaryVariation_Group2Var2: return "Group2Var2";
        case EventBinaryVariation_Group2Var3: return "Group2Var3";
        default: return "";
    }
}

typedef struct binary_config_t binary_config_t;

/// @brief Binary Input configuration
typedef struct binary_config_t
{
    /// @brief Default static variation
    /// @note Default value is @ref StaticBinaryVariation_Group1Var1
    static_binary_variation_t static_variation;
    /// @brief Default event variation
    /// @note Default value is @ref EventBinaryVariation_Group2Var1
    event_binary_variation_t event_variation;
} binary_config_t;

static binary_config_t binary_config_init()
{
    return (binary_config_t)
    {
        .static_variation = StaticBinaryVariation_Group1Var1,
        .event_variation = EventBinaryVariation_Group2Var1,
    };
}

/// @brief Add a new Binary Input point
/// @param db Database
/// @param index Index of the point
/// @param point_class Event class
/// @param config Configuration
void database_add_binary(database_t* db, uint16_t index, event_class_t point_class, binary_config_t config);

/// @brief Remove a Binary Input point
/// @param db Database
/// @param index Index of the point
void database_remove_binary(database_t* db, uint16_t index);

/// @brief Update a Binary Input point
/// @param db Database
/// @param value New value of the point
/// @param options Update options
void database_update_binary(database_t* db, binary_t value, update_options_t options);

/// @brief Static double-bit binary input variation
typedef enum static_double_bit_binary_variation_t
{
    /// @brief Double-bit binary input - packed format
    StaticDoubleBitBinaryVariation_Group3Var1 = 0,
    /// @brief Double-bit binary input - with flags
    StaticDoubleBitBinaryVariation_Group3Var2 = 1,
} static_double_bit_binary_variation_t;

static const char* StaticDoubleBitBinaryVariation_to_string(static_double_bit_binary_variation_t value)
{
    switch (value)
    {
        case StaticDoubleBitBinaryVariation_Group3Var1: return "Group3Var1";
        case StaticDoubleBitBinaryVariation_Group3Var2: return "Group3Var2";
        default: return "";
    }
}

/// @brief Event double-bit binary input variation
typedef enum event_double_bit_binary_variation_t
{
    /// @brief Double-bit binary input event - without time
    EventDoubleBitBinaryVariation_Group4Var1 = 0,
    /// @brief Double-bit binary input event - with absolute time
    EventDoubleBitBinaryVariation_Group4Var2 = 1,
    /// @brief Double-bit binary input event - with relative time
    EventDoubleBitBinaryVariation_Group4Var3 = 2,
} event_double_bit_binary_variation_t;

static const char* EventDoubleBitBinaryVariation_to_string(event_double_bit_binary_variation_t value)
{
    switch (value)
    {
        case EventDoubleBitBinaryVariation_Group4Var1: return "Group4Var1";
        case EventDoubleBitBinaryVariation_Group4Var2: return "Group4Var2";
        case EventDoubleBitBinaryVariation_Group4Var3: return "Group4Var3";
        default: return "";
    }
}

typedef struct double_bit_binary_config_t double_bit_binary_config_t;

/// @brief Double-Bit Binary Input configuration
typedef struct double_bit_binary_config_t
{
    /// @brief Default static variation
    /// @note Default value is @ref StaticDoubleBitBinaryVariation_Group3Var1
    static_double_bit_binary_variation_t static_variation;
    /// @brief Default event variation
    /// @note Default value is @ref EventDoubleBitBinaryVariation_Group4Var1
    event_double_bit_binary_variation_t event_variation;
} double_bit_binary_config_t;

static double_bit_binary_config_t double_bit_binary_config_init()
{
    return (double_bit_binary_config_t)
    {
        .static_variation = StaticDoubleBitBinaryVariation_Group3Var1,
        .event_variation = EventDoubleBitBinaryVariation_Group4Var1,
    };
}

/// @brief Add a new Double-Bit Binary Input point
/// @param db Database
/// @param index Index of the point
/// @param point_class Event class
/// @param config Configuration
void database_add_double_bit_binary(database_t* db, uint16_t index, event_class_t point_class, double_bit_binary_config_t config);

/// @brief Remove a Double-Bit Binary Input point
/// @param db Database
/// @param index Index of the point
void database_remove_double_bit_binary(database_t* db, uint16_t index);

/// @brief Update a Double-Bit Binary Input point
/// @param db Database
/// @param value New value of the point
/// @param options Update options
void database_update_double_bit_binary(database_t* db, double_bit_binary_t value, update_options_t options);

/// @brief Static binary output status variation
typedef enum static_binary_output_status_variation_t
{
    /// @brief Binary output - packed format
    StaticBinaryOutputStatusVariation_Group10Var1 = 0,
    /// @brief Binary output - output status with flags
    StaticBinaryOutputStatusVariation_Group10Var2 = 1,
} static_binary_output_status_variation_t;

static const char* StaticBinaryOutputStatusVariation_to_string(static_binary_output_status_variation_t value)
{
    switch (value)
    {
        case StaticBinaryOutputStatusVariation_Group10Var1: return "Group10Var1";
        case StaticBinaryOutputStatusVariation_Group10Var2: return "Group10Var2";
        default: return "";
    }
}

/// @brief Event binary output status variation
typedef enum event_binary_output_status_variation_t
{
    /// @brief Binary output event - status without time
    EventBinaryOutputStatusVariation_Group11Var1 = 0,
    /// @brief Binary output event - status with time
    EventBinaryOutputStatusVariation_Group11Var2 = 1,
} event_binary_output_status_variation_t;

static const char* EventBinaryOutputStatusVariation_to_string(event_binary_output_status_variation_t value)
{
    switch (value)
    {
        case EventBinaryOutputStatusVariation_Group11Var1: return "Group11Var1";
        case EventBinaryOutputStatusVariation_Group11Var2: return "Group11Var2";
        default: return "";
    }
}

typedef struct binary_output_status_config_t binary_output_status_config_t;

/// @brief Binary Output Status configuration
typedef struct binary_output_status_config_t
{
    /// @brief Default static variation
    /// @note Default value is @ref StaticBinaryOutputStatusVariation_Group10Var1
    static_binary_output_status_variation_t static_variation;
    /// @brief Default event variation
    /// @note Default value is @ref EventBinaryOutputStatusVariation_Group11Var2
    event_binary_output_status_variation_t event_variation;
} binary_output_status_config_t;

static binary_output_status_config_t binary_output_status_config_init()
{
    return (binary_output_status_config_t)
    {
        .static_variation = StaticBinaryOutputStatusVariation_Group10Var1,
        .event_variation = EventBinaryOutputStatusVariation_Group11Var2,
    };
}

/// @brief Add a new Binary Output Status point
/// @param db Database
/// @param index Index of the point
/// @param point_class Event class
/// @param config Configuration
void database_add_binary_output_status(database_t* db, uint16_t index, event_class_t point_class, binary_output_status_config_t config);

/// @brief Remove a Binary Output Status point
/// @param db Database
/// @param index Index of the point
void database_remove_binary_output_status(database_t* db, uint16_t index);

/// @brief Update a Binary Output Status point
/// @param db Database
/// @param value New value of the point
/// @param options Update options
void database_update_binary_output_status(database_t* db, binary_output_status_t value, update_options_t options);

/// @brief Static counter variation
typedef enum static_counter_variation_t
{
    /// @brief Counter - 32-bit with flag
    StaticCounterVariation_Group20Var1 = 0,
    /// @brief Counter - 16-bit with flag
    StaticCounterVariation_Group20Var2 = 1,
    /// @brief Counter - 32-bit without flag
    StaticCounterVariation_Group20Var5 = 2,
    /// @brief Counter - 16-bit without flag
    StaticCounterVariation_Group20Var6 = 3,
} static_counter_variation_t;

static const char* StaticCounterVariation_to_string(static_counter_variation_t value)
{
    switch (value)
    {
        case StaticCounterVariation_Group20Var1: return "Group20Var1";
        case StaticCounterVariation_Group20Var2: return "Group20Var2";
        case StaticCounterVariation_Group20Var5: return "Group20Var5";
        case StaticCounterVariation_Group20Var6: return "Group20Var6";
        default: return "";
    }
}

/// @brief Event counter variation
typedef enum event_counter_variation_t
{
    /// @brief Counter event - 32-bit with flag
    EventCounterVariation_Group22Var1 = 0,
    /// @brief Counter event - 16-bit with flag
    EventCounterVariation_Group22Var2 = 1,
    /// @brief Counter event - 32-bit with flag and time
    EventCounterVariation_Group22Var5 = 2,
    /// @brief Counter event - 16-bit with flag and time
    EventCounterVariation_Group22Var6 = 3,
} event_counter_variation_t;

static const char* EventCounterVariation_to_string(event_counter_variation_t value)
{
    switch (value)
    {
        case EventCounterVariation_Group22Var1: return "Group22Var1";
        case EventCounterVariation_Group22Var2: return "Group22Var2";
        case EventCounterVariation_Group22Var5: return "Group22Var5";
        case EventCounterVariation_Group22Var6: return "Group22Var6";
        default: return "";
    }
}

typedef struct counter_config_t counter_config_t;

/// @brief Counter configuration
typedef struct counter_config_t
{
    /// @brief Default static variation
    /// @note Default value is @ref StaticCounterVariation_Group20Var1
    static_counter_variation_t static_variation;
    /// @brief Default event variation
    /// @note Default value is @ref EventCounterVariation_Group22Var1
    event_counter_variation_t event_variation;
    /// @brief Deadband value
    /// @note Default value is 0
    uint32_t deadband;
} counter_config_t;

static counter_config_t counter_config_init()
{
    return (counter_config_t)
    {
        .static_variation = StaticCounterVariation_Group20Var1,
        .event_variation = EventCounterVariation_Group22Var1,
        .deadband = 0,
    };
}

/// @brief Add a new Counter point
/// @param db Database
/// @param index Index of the point
/// @param point_class Event class
/// @param config Configuration
void database_add_counter(database_t* db, uint16_t index, event_class_t point_class, counter_config_t config);

/// @brief Remove a Counter point
/// @param db Database
/// @param index Index of the point
void database_remove_counter(database_t* db, uint16_t index);

/// @brief Update a Counter point
/// @param db Database
/// @param value New value of the point
/// @param options Update options
void database_update_counter(database_t* db, counter_t value, update_options_t options);

/// @brief Static frozen counter variation
typedef enum static_frozen_counter_variation_t
{
    /// @brief Frozen Counter - 32-bit with flag
    StaticFrozenCounterVariation_Group21Var1 = 0,
    /// @brief Frozen Counter - 16-bit with flag
    StaticFrozenCounterVariation_Group21Var2 = 1,
    /// @brief Frozen Counter - 32-bit with flag and time
    StaticFrozenCounterVariation_Group21Var5 = 2,
    /// @brief Frozen Counter - 16-bit with flag and time
    StaticFrozenCounterVariation_Group21Var6 = 3,
    /// @brief Frozen Counter - 32-bit without flag
    StaticFrozenCounterVariation_Group21Var9 = 4,
    /// @brief Frozen Counter - 16-bit without flag
    StaticFrozenCounterVariation_Group21Var10 = 5,
} static_frozen_counter_variation_t;

static const char* StaticFrozenCounterVariation_to_string(static_frozen_counter_variation_t value)
{
    switch (value)
    {
        case StaticFrozenCounterVariation_Group21Var1: return "Group21Var1";
        case StaticFrozenCounterVariation_Group21Var2: return "Group21Var2";
        case StaticFrozenCounterVariation_Group21Var5: return "Group21Var5";
        case StaticFrozenCounterVariation_Group21Var6: return "Group21Var6";
        case StaticFrozenCounterVariation_Group21Var9: return "Group21Var9";
        case StaticFrozenCounterVariation_Group21Var10: return "Group21Var10";
        default: return "";
    }
}

/// @brief Event frozen counter variation
typedef enum event_frozen_counter_variation_t
{
    /// @brief Frozen Counter event - 32-bit with flag
    EventFrozenCounterVariation_Group23Var1 = 0,
    /// @brief Frozen Counter event - 16-bit with flag
    EventFrozenCounterVariation_Group23Var2 = 1,
    /// @brief Frozen Counter event - 32-bit with flag and time
    EventFrozenCounterVariation_Group23Var5 = 2,
    /// @brief Frozen Counter event - 16-bit with flag and time
    EventFrozenCounterVariation_Group23Var6 = 3,
} event_frozen_counter_variation_t;

static const char* EventFrozenCounterVariation_to_string(event_frozen_counter_variation_t value)
{
    switch (value)
    {
        case EventFrozenCounterVariation_Group23Var1: return "Group23Var1";
        case EventFrozenCounterVariation_Group23Var2: return "Group23Var2";
        case EventFrozenCounterVariation_Group23Var5: return "Group23Var5";
        case EventFrozenCounterVariation_Group23Var6: return "Group23Var6";
        default: return "";
    }
}

typedef struct frozen_counter_config_t frozen_counter_config_t;

/// @brief Frozen Counter configuration
typedef struct frozen_counter_config_t
{
    /// @brief Default static variation
    /// @note Default value is @ref StaticFrozenCounterVariation_Group21Var1
    static_frozen_counter_variation_t static_variation;
    /// @brief Default event variation
    /// @note Default value is @ref EventFrozenCounterVariation_Group23Var1
    event_frozen_counter_variation_t event_variation;
    /// @brief Deadband value
    /// @note Default value is 0
    uint32_t deadband;
} frozen_counter_config_t;

static frozen_counter_config_t frozen_counter_config_init()
{
    return (frozen_counter_config_t)
    {
        .static_variation = StaticFrozenCounterVariation_Group21Var1,
        .event_variation = EventFrozenCounterVariation_Group23Var1,
        .deadband = 0,
    };
}

/// @brief Add a new Frozen Counter point
/// @param db Database
/// @param index Index of the point
/// @param point_class Event class
/// @param config Configuration
void database_add_frozen_counter(database_t* db, uint16_t index, event_class_t point_class, frozen_counter_config_t config);

/// @brief Remove a Frozen Counter point
/// @param db Database
/// @param index Index of the point
void database_remove_frozen_counter(database_t* db, uint16_t index);

/// @brief Update an Analog point
/// @param db Database
/// @param value New value of the point
/// @param options Update options
void database_update_frozen_counter(database_t* db, frozen_counter_t value, update_options_t options);

/// @brief Static analog variation
typedef enum static_analog_variation_t
{
    /// @brief Analog input - 32-bit with flag
    StaticAnalogVariation_Group30Var1 = 0,
    /// @brief Analog input - 16-bit with flag
    StaticAnalogVariation_Group30Var2 = 1,
    /// @brief Analog input - 32-bit without flag
    StaticAnalogVariation_Group30Var3 = 2,
    /// @brief Analog input - 16-bit without flag
    StaticAnalogVariation_Group30Var4 = 3,
    /// @brief Analog input - single-precision, floating-point with flag
    StaticAnalogVariation_Group30Var5 = 4,
    /// @brief Analog input - double-precision, floating-point with flag
    StaticAnalogVariation_Group30Var6 = 5,
} static_analog_variation_t;

static const char* StaticAnalogVariation_to_string(static_analog_variation_t value)
{
    switch (value)
    {
        case StaticAnalogVariation_Group30Var1: return "Group30Var1";
        case StaticAnalogVariation_Group30Var2: return "Group30Var2";
        case StaticAnalogVariation_Group30Var3: return "Group30Var3";
        case StaticAnalogVariation_Group30Var4: return "Group30Var4";
        case StaticAnalogVariation_Group30Var5: return "Group30Var5";
        case StaticAnalogVariation_Group30Var6: return "Group30Var6";
        default: return "";
    }
}

/// @brief Event analog variation
typedef enum event_analog_variation_t
{
    /// @brief Analog input event - 32-bit without time
    EventAnalogVariation_Group32Var1 = 0,
    /// @brief Analog input event - 16-bit without time
    EventAnalogVariation_Group32Var2 = 1,
    /// @brief Analog input event - 32-bit with time
    EventAnalogVariation_Group32Var3 = 2,
    /// @brief Analog input event - 16-bit with time
    EventAnalogVariation_Group32Var4 = 3,
    /// @brief Analog input event - single-precision, floating-point without time
    EventAnalogVariation_Group32Var5 = 4,
    /// @brief Analog input event - double-precision, floating-point without time
    EventAnalogVariation_Group32Var6 = 5,
    /// @brief Analog input event - single-precision, floating-point with time
    EventAnalogVariation_Group32Var7 = 6,
    /// @brief Analog input event - double-precision, floating-point with time
    EventAnalogVariation_Group32Var8 = 7,
} event_analog_variation_t;

static const char* EventAnalogVariation_to_string(event_analog_variation_t value)
{
    switch (value)
    {
        case EventAnalogVariation_Group32Var1: return "Group32Var1";
        case EventAnalogVariation_Group32Var2: return "Group32Var2";
        case EventAnalogVariation_Group32Var3: return "Group32Var3";
        case EventAnalogVariation_Group32Var4: return "Group32Var4";
        case EventAnalogVariation_Group32Var5: return "Group32Var5";
        case EventAnalogVariation_Group32Var6: return "Group32Var6";
        case EventAnalogVariation_Group32Var7: return "Group32Var7";
        case EventAnalogVariation_Group32Var8: return "Group32Var8";
        default: return "";
    }
}

typedef struct analog_config_t analog_config_t;

/// @brief Analog configuration
typedef struct analog_config_t
{
    /// @brief Default static variation
    /// @note Default value is @ref StaticAnalogVariation_Group30Var1
    static_analog_variation_t static_variation;
    /// @brief Default event variation
    /// @note Default value is @ref EventAnalogVariation_Group32Var1
    event_analog_variation_t event_variation;
    /// @brief Deadband value
    /// @note Default value is 0
    double deadband;
} analog_config_t;

static analog_config_t analog_config_init()
{
    return (analog_config_t)
    {
        .static_variation = StaticAnalogVariation_Group30Var1,
        .event_variation = EventAnalogVariation_Group32Var1,
        .deadband = 0,
    };
}

/// @brief Add a new Analog point
/// @param db Database
/// @param index Index of the point
/// @param point_class Event class
/// @param config Configuration
void database_add_analog(database_t* db, uint16_t index, event_class_t point_class, analog_config_t config);

/// @brief Remove an Analog point
/// @param db Database
/// @param index Index of the point
void database_remove_analog(database_t* db, uint16_t index);

/// @brief Update a Analog point
/// @param db Database
/// @param value New value of the point
/// @param options Update options
void database_update_analog(database_t* db, analog_t value, update_options_t options);

/// @brief Static analog output status variation
typedef enum static_analog_output_status_variation_t
{
    /// @brief Analog output status - 32-bit with flag
    StaticAnalogOutputStatusVariation_Group40Var1 = 0,
    /// @brief Analog output status - 16-bit with flag
    StaticAnalogOutputStatusVariation_Group40Var2 = 1,
    /// @brief Analog output status - single-precision, floating-point with flag
    StaticAnalogOutputStatusVariation_Group40Var3 = 2,
    /// @brief Analog output status - double-precision, floating-point with flag
    StaticAnalogOutputStatusVariation_Group40Var4 = 3,
} static_analog_output_status_variation_t;

static const char* StaticAnalogOutputStatusVariation_to_string(static_analog_output_status_variation_t value)
{
    switch (value)
    {
        case StaticAnalogOutputStatusVariation_Group40Var1: return "Group40Var1";
        case StaticAnalogOutputStatusVariation_Group40Var2: return "Group40Var2";
        case StaticAnalogOutputStatusVariation_Group40Var3: return "Group40Var3";
        case StaticAnalogOutputStatusVariation_Group40Var4: return "Group40Var4";
        default: return "";
    }
}

/// @brief Event analog output status variation
typedef enum event_analog_output_status_variation_t
{
    /// @brief Analog output event - 32-bit without time
    EventAnalogOutputStatusVariation_Group42Var1 = 0,
    /// @brief Analog output event - 16-bit without time
    EventAnalogOutputStatusVariation_Group42Var2 = 1,
    /// @brief Analog output event - 32-bit with time
    EventAnalogOutputStatusVariation_Group42Var3 = 2,
    /// @brief Analog output event - 16-bit with time
    EventAnalogOutputStatusVariation_Group42Var4 = 3,
    /// @brief Analog output event - single-precision, floating-point without time
    EventAnalogOutputStatusVariation_Group42Var5 = 4,
    /// @brief Analog output event - double-precision, floating-point without time
    EventAnalogOutputStatusVariation_Group42Var6 = 5,
    /// @brief Analog output event - single-precision, floating-point with time
    EventAnalogOutputStatusVariation_Group42Var7 = 6,
    /// @brief Analog output event - double-precision, floating-point with time
    EventAnalogOutputStatusVariation_Group42Var8 = 7,
} event_analog_output_status_variation_t;

static const char* EventAnalogOutputStatusVariation_to_string(event_analog_output_status_variation_t value)
{
    switch (value)
    {
        case EventAnalogOutputStatusVariation_Group42Var1: return "Group42Var1";
        case EventAnalogOutputStatusVariation_Group42Var2: return "Group42Var2";
        case EventAnalogOutputStatusVariation_Group42Var3: return "Group42Var3";
        case EventAnalogOutputStatusVariation_Group42Var4: return "Group42Var4";
        case EventAnalogOutputStatusVariation_Group42Var5: return "Group42Var5";
        case EventAnalogOutputStatusVariation_Group42Var6: return "Group42Var6";
        case EventAnalogOutputStatusVariation_Group42Var7: return "Group42Var7";
        case EventAnalogOutputStatusVariation_Group42Var8: return "Group42Var8";
        default: return "";
    }
}

typedef struct analog_output_status_config_t analog_output_status_config_t;

/// @brief Analog Output Status configuration
typedef struct analog_output_status_config_t
{
    /// @brief Default static variation
    /// @note Default value is @ref StaticAnalogOutputStatusVariation_Group40Var1
    static_analog_output_status_variation_t static_variation;
    /// @brief Default event variation
    /// @note Default value is @ref EventAnalogOutputStatusVariation_Group42Var1
    event_analog_output_status_variation_t event_variation;
    /// @brief Deadband value
    /// @note Default value is 0
    double deadband;
} analog_output_status_config_t;

static analog_output_status_config_t analog_output_status_config_init()
{
    return (analog_output_status_config_t)
    {
        .static_variation = StaticAnalogOutputStatusVariation_Group40Var1,
        .event_variation = EventAnalogOutputStatusVariation_Group42Var1,
        .deadband = 0,
    };
}

/// @brief Add a new Analog Output Status point
/// @param db Database
/// @param index Index of the point
/// @param point_class Event class
/// @param config Configuration
void database_add_analog_output_status(database_t* db, uint16_t index, event_class_t point_class, analog_output_status_config_t config);

/// @brief Remove an Analog Output Status point
/// @param db Database
/// @param index Index of the point
void database_remove_analog_output_status(database_t* db, uint16_t index);

/// @brief Update a Analog Output Status point
/// @param db Database
/// @param value New value of the point
/// @param options Update options
void database_update_analog_output_status(database_t* db, analog_output_status_t value, update_options_t options);

/// @brief Collection of uint8_t. See @ref octet_string_add and @ref octet_string_destroy.
typedef struct octet_string_value_t octet_string_value_t;

/// @brief Create a new octet string
/// @return Empty octet string
octet_string_value_t* octet_string_new();

/// @brief Deallocate an octet string
/// @param octet_string Octet String to destroy
void octet_string_destroy(octet_string_value_t* octet_string);

/// @brief Create a new octet string
/// @param octet_string Octet String to modify
/// @param value Byte to add
void octet_string_add(octet_string_value_t* octet_string, uint8_t value);


/// @brief Add a new Octet String point
/// @param db Database
/// @param index Index of the point
/// @param point_class Event class
void database_add_octet_string(database_t* db, uint16_t index, event_class_t point_class);

/// @brief Remove an Octet String point
/// @param db Database
/// @param index Index of the point
void database_remove_octet_string(database_t* db, uint16_t index);

/// @brief Update an Octet String point
/// @param db Database
/// @param index Index of the octet string
/// @param value New value of the point
/// @param options Update options
void database_update_octet_string(database_t* db, uint16_t index, octet_string_value_t* value, update_options_t options);


/// @brief Outstation transaction interface
typedef struct outstation_transaction_t
{
    
    /// @brief Execute the transaction with the provided database
    /// @param database Database
    /// @param ctx Context data
    void (*execute)(database_t*, void*);
    /// @brief Context data
    void* ctx;
} outstation_transaction_t;

/// @brief Outstation handle
/// 
/// Use this handle to modify the internal database.
typedef struct outstation_t outstation_t;

/// @brief Free resources of the outstation.
/// 
/// @warning This does not shutdown the outstation. Only @ref tcpserver_destroy will properly shutdown the outstation.
/// @param outstation Outstation to destroy
void outstation_destroy(outstation_t* outstation);

/// @brief Execute transaction to modify the internal database of the outstation
/// @param outstation Outstation
/// @param callback Method to execute as a transaction
void outstation_transaction(outstation_t* outstation, outstation_transaction_t callback);

/// @brief Set decoding log level
/// @param outstation @ref outstation_t on which to set the decoding level
/// @param level Decode log
void outstation_set_decode_level(outstation_t* outstation, decode_level_t level);


typedef struct class_zero_config_t class_zero_config_t;

/// @brief Controls which types are reported during a Class 0 read.
typedef struct class_zero_config_t
{
    /// @brief Include Binary Inputs in Class 0 reads
    /// @note Default value is true
    bool binary;
    /// @brief Include Double-Bit Binary Inputs in Class 0 reads
    /// @note Default value is true
    bool double_bit_binary;
    /// @brief Include Binary Output Status in Class 0 reads
    /// @note Default value is true
    bool binary_output_status;
    /// @brief Include Counters in Class 0 reads
    /// @note Default value is true
    bool counter;
    /// @brief Include Frozen Counters in Class 0 reads
    /// @note Default value is true
    bool frozen_counter;
    /// @brief Include Analog Inputs in Class 0 reads
    /// @note Default value is true
    bool analog;
    /// @brief Include Analog Output Status in Class 0 reads
    /// @note Default value is true
    bool analog_output_status;
    /// @brief Include Binary Inputs in Class 0 reads
    /// 
    /// @warning For conformance, this should be false.
    /// @note Default value is false
    bool octet_strings;
} class_zero_config_t;

static class_zero_config_t class_zero_config_init()
{
    return (class_zero_config_t)
    {
        .binary = true,
        .double_bit_binary = true,
        .binary_output_status = true,
        .counter = true,
        .frozen_counter = true,
        .analog = true,
        .analog_output_status = true,
        .octet_strings = false,
    };
}

typedef struct outstation_features_t outstation_features_t;

/// @brief Optional outstation features that can be enabled or disabled
typedef struct outstation_features_t
{
    /// @brief Respond to the self address
    /// @note Default value is false
    bool self_address;
    /// @brief Process valid broadcast messages
    /// @note Default value is true
    bool broadcast;
    /// @brief Respond to enable/disable unsolicited response and produce unsolicited responses
    /// @note Default value is true
    bool unsolicited;
} outstation_features_t;

static outstation_features_t outstation_features_init()
{
    return (outstation_features_t)
    {
        .self_address = false,
        .broadcast = true,
        .unsolicited = true,
    };
}

typedef struct outstation_config_t outstation_config_t;

/// @brief Outstation configuration
typedef struct outstation_config_t
{
    /// @brief Link-layer outstation address
    uint16_t outstation_address;
    /// @brief Link-layer master address
    uint16_t master_address;
    /// @brief Solicited response buffer size
    /// 
    /// Must be at least 249 bytes
    /// @note Default value is 2048
    uint16_t solicited_buffer_size;
    /// @brief Unsolicited response buffer size
    /// 
    /// Must be at least 249 bytes
    /// @note Default value is 2048
    uint16_t unsolicited_buffer_size;
    /// @brief Receive buffer size
    /// 
    /// Must be at least 249 bytes
    /// @note Default value is 2048
    uint16_t rx_buffer_size;
    /// @brief Decoding level
    decode_level_t decode_level;
    /// @brief Confirmation timeout
    /// @note Default value is 5s
    uint64_t confirm_timeout;
    /// @brief Select timeout
    /// @note Default value is 5s
    uint64_t select_timeout;
    /// @brief Optional features
    outstation_features_t features;
    /// @brief Maximum number of unsolicited retries
    /// @note Default value is 4294967295
    uint32_t max_unsolicited_retries;
    /// @brief Delay to wait before retrying an unsolicited response
    /// @note Default value is 5s
    uint64_t unsolicited_retry_delay;
    /// @brief Maximum number of read headers per request
    /// @note Default value is 64
    uint16_t max_read_headers_per_request;
    /// @brief Delay of inactivity before sending a REQUEST_LINK_STATUS to the master
    /// 
    /// A value of zero means no automatic keep-alives.
    /// @note Default value is 60s
    uint64_t keep_alive_timeout;
    /// @brief Maximum number of headers that will be processed in a READ request.
    /// 
    /// Internally, this controls the size of a pre-allocated buffer used to process requests. A minimum value of `DEFAULT_READ_REQUEST_HEADERS` is always enforced. Requesting more than this number will result in the PARAMETER_ERROR IIN bit being set in the response.
    /// @note Default value is 64
    uint16_t max_read_request_headers;
    /// @brief Controls responses to Class 0 reads
    class_zero_config_t class_zero;
} outstation_config_t;

static outstation_config_t outstation_config_init(uint16_t outstation_address, uint16_t master_address)
{
    return (outstation_config_t)
    {
        .outstation_address = outstation_address,
        .master_address = master_address,
        .solicited_buffer_size = 2048,
        .unsolicited_buffer_size = 2048,
        .rx_buffer_size = 2048,
        .decode_level = decode_level_init(),
        .confirm_timeout = 5000,
        .select_timeout = 5000,
        .features = outstation_features_init(),
        .max_unsolicited_retries = 4294967295,
        .unsolicited_retry_delay = 5000,
        .max_read_headers_per_request = 64,
        .keep_alive_timeout = 60000,
        .max_read_request_headers = 64,
        .class_zero = class_zero_config_init(),
    };
}

typedef struct event_buffer_config_t event_buffer_config_t;

/// @brief Maximum number of events for each type
/// 
/// A value of zero means that events will not be buffered for that type.
typedef struct event_buffer_config_t
{
    /// @brief Maximum number of Binary Input events (g2)
    uint16_t max_binary;
    /// @brief Maximum number of Double-Bit Binary Input events (g4)
    uint16_t max_double_bit_binary;
    /// @brief Maximum number of Binary Output Status events (g11)
    uint16_t max_binary_output_status;
    /// @brief Maximum number of Counter events (g22)
    uint16_t max_counter;
    /// @brief Maximum number of Frozen Counter events (g23)
    uint16_t max_frozen_counter;
    /// @brief Maximum number of Analog Input events (g32)
    uint16_t max_analog;
    /// @brief Maximum number of Analog Output Status events (g42)
    uint16_t max_analog_output_status;
    /// @brief Maximum number of Octet String events (g111)
    uint16_t max_octet_string;
} event_buffer_config_t;

static event_buffer_config_t event_buffer_config_init(uint16_t max_binary, uint16_t max_double_bit_binary, uint16_t max_binary_output_status, uint16_t max_counter, uint16_t max_frozen_counter, uint16_t max_analog, uint16_t max_analog_output_status, uint16_t max_octet_string)
{
    return (event_buffer_config_t)
    {
        .max_binary = max_binary,
        .max_double_bit_binary = max_double_bit_binary,
        .max_binary_output_status = max_binary_output_status,
        .max_counter = max_counter,
        .max_frozen_counter = max_frozen_counter,
        .max_analog = max_analog,
        .max_analog_output_status = max_analog_output_status,
        .max_octet_string = max_octet_string,
    };
}

/// @brief Initialize an event buffer configuration with the same maximum values for all types
/// @param max Maximum value to set all types
/// @return Event buffer configuration
event_buffer_config_t event_buffer_config_all_types(uint16_t max);

/// @brief Initialize an event buffer configuration to support no events
/// @return Event buffer configuration
event_buffer_config_t event_buffer_config_no_events();


/// @brief Type of restart delay value. Used by @ref restart_delay_t.
typedef enum restart_delay_type_t
{
    /// @brief Restart mode not supported
    RestartDelayType_NotSupported = 0,
    /// @brief Value is in seconds (corresponds to g51v1)
    RestartDelayType_Seconds = 1,
    /// @brief Value is in milliseconds (corresponds to g51v2)
    RestartDelayType_Milliseconds = 2,
} restart_delay_type_t;

static const char* RestartDelayType_to_string(restart_delay_type_t value)
{
    switch (value)
    {
        case RestartDelayType_NotSupported: return "NotSupported";
        case RestartDelayType_Seconds: return "Seconds";
        case RestartDelayType_Milliseconds: return "Milliseconds";
        default: return "";
    }
}

typedef struct restart_delay_t restart_delay_t;

/// @brief Restart delay used by @ref outstation_application_t.cold_restart and @ref outstation_application_t.warm_restart
/// 
/// If @ref restart_delay_t.restart_type is not @ref RestartDelayType_NotSupported, then the @ref restart_delay_t.value is valid. Otherwise, the outstation will return IIN2.0 NO_FUNC_CODE_SUPPORT.
typedef struct restart_delay_t
{
    /// @brief Indicates what @ref restart_delay_t.value is.
    restart_delay_type_t restart_type;
    /// @brief Expected delay before the outstation comes back online.
    uint16_t value;
} restart_delay_t;

static restart_delay_t restart_delay_init(restart_delay_type_t restart_type, uint16_t value)
{
    return (restart_delay_t)
    {
        .restart_type = restart_type,
        .value = value,
    };
}

/// @brief Creates a restart delay that indicates that this operation is not supported.
/// @return Unsupported restart delay
restart_delay_t restart_delay_not_supported();

/// @brief Creates a restart delay with a value specified in seconds.
/// @param value Expected restart delay (in seconds)
/// @return Valid restart delay
restart_delay_t restart_delay_seconds(uint16_t value);

/// @brief Creates a restart delay with a value specified in milliseconds.
/// @param value Expected restart delay (in milliseconds)
/// @return Valid restart delay
restart_delay_t restart_delay_millis(uint16_t value);


/// @brief Dynamic information required by the outstation from the user application
typedef struct outstation_application_t
{
    
    /// @brief Returns the DELAY_MEASUREMENT delay
    /// 
    /// The value returned by this method is used in conjunction with the DELAY_MEASUREMENT function code and returned in a g52v2 time delay object as part of a non-LAN time synchronization procedure.
    /// 
    /// It represents the processing delay from receiving the request to sending the response. This parameter should almost always use the default value of zero as only an RTOS or bare metal system would have access to this level of timing. Modern hardware can almost always respond in less than 1 millisecond anyway.
    /// 
    /// For more information, see IEEE-1815 2012, p. 64.
    /// @param ctx Context data
    /// @return Processing delay, in milliseconds
    uint16_t (*get_processing_delay_ms)(void*);
    
    /// @brief Request that the outstation perform a cold restart (IEEE-1815 2012, p. 58)
    /// 
    /// The outstation will not automatically restart. It is the responsibility of the user application to handle this request and take the appropriate action.
    /// @param ctx Context data
    /// @return The restart delay
    restart_delay_t (*cold_restart)(void*);
    
    /// @brief Request that the outstation perform a warm restart (IEEE-1815 2012, p. 58)
    /// 
    /// The outstation will not automatically restart. It is the responsibility of the user application to handle this request and take the appropriate action.
    /// @param ctx Context data
    /// @return The restart delay
    restart_delay_t (*warm_restart)(void*);
    /// @brief Callback when the underlying owner doesn't need the callback anymore
    /// @param arg Context data
    void (*on_destroy)(void* arg);
    /// @brief Context data
    void* ctx;
} outstation_application_t;

/// @brief Application layer function code
typedef enum function_code_t
{
    /// @brief Master sends this to an outstation to confirm the receipt of an Application Layer fragment (value == 0)
    FunctionCode_Confirm = 0,
    /// @brief Outstation shall return the data specified by the objects in the request (value == 1)
    FunctionCode_Read = 1,
    /// @brief Outstation shall store the data specified by the objects in the request (value == 2)
    FunctionCode_Write = 2,
    /// @brief Outstation shall select (or arm) the output points specified by the objects in the request in preparation for a subsequent operate command (value == 3)
    FunctionCode_Select = 3,
    /// @brief Outstation shall activate the output points selected (or armed) by a previous select function code command (value == 4)
    FunctionCode_Operate = 4,
    /// @brief Outstation shall immediately actuate the output points specified by the objects in the request (value == 5)
    FunctionCode_DirectOperate = 5,
    /// @brief Same as DirectOperate but outstation shall not send a response (value == 6)
    FunctionCode_DirectOperateNoResponse = 6,
    /// @brief Outstation shall copy the point data values specified by the objects in the request to a separate freeze buffer (value == 7)
    FunctionCode_ImmediateFreeze = 7,
    /// @brief Same as ImmediateFreeze but outstation shall not send a response (value == 8)
    FunctionCode_ImmediateFreezeNoResponse = 8,
    /// @brief Outstation shall copy the point data values specified by the objects in the request into a separate freeze buffer and then clear the values (value == 9)
    FunctionCode_FreezeClear = 9,
    /// @brief Same as FreezeClear but outstation shall not send a response (value == 10)
    FunctionCode_FreezeClearNoResponse = 10,
    /// @brief Outstation shall copy the point data values specified by the objects in the request to a separate freeze buffer at the time and/or time intervals specified in a special time data information object (value == 11)
    FunctionCode_FreezeAtTime = 11,
    /// @brief Same as FreezeAtTime but outstation shall not send a response (value == 12)
    FunctionCode_FreezeAtTimeNoResponse = 12,
    /// @brief Outstation shall perform a complete reset of all hardware and software in the device (value == 13)
    FunctionCode_ColdRestart = 13,
    /// @brief Outstation shall reset only portions of the device (value == 14)
    FunctionCode_WarmRestart = 14,
    /// @brief Obsolete-Do not use for new designs (value == 15)
    FunctionCode_InitializeData = 15,
    /// @brief Outstation shall place the applications specified by the objects in the request into the ready to run state (value == 16)
    FunctionCode_InitializeApplication = 16,
    /// @brief Outstation shall start running the applications specified by the objects in the request (value == 17)
    FunctionCode_StartApplication = 17,
    /// @brief Outstation shall stop running the applications specified by the objects in the request (value == 18)
    FunctionCode_StopApplication = 18,
    /// @brief This code is deprecated-Do not use for new designs (value == 19)
    FunctionCode_SaveConfiguration = 19,
    /// @brief Enables outstation to initiate unsolicited responses from points specified by the objects in the request (value == 20)
    FunctionCode_EnableUnsolicited = 20,
    /// @brief Prevents outstation from initiating unsolicited responses from points specified by the objects in the request (value == 21)
    FunctionCode_DisableUnsolicited = 21,
    /// @brief Outstation shall assign the events generated by the points specified by the objects in the request to one of the classes (value == 22)
    FunctionCode_AssignClass = 22,
    /// @brief Outstation shall report the time it takes to process and initiate the transmission of its response (value == 23)
    FunctionCode_DelayMeasure = 23,
    /// @brief Outstation shall save the time when the last octet of this message is received (value == 24)
    FunctionCode_RecordCurrentTime = 24,
    /// @brief Outstation shall open a file (value == 25)
    FunctionCode_OpenFile = 25,
    /// @brief Outstation shall close a file (value == 26)
    FunctionCode_CloseFile = 26,
    /// @brief Outstation shall delete a file (value == 27)
    FunctionCode_DeleteFile = 27,
    /// @brief Outstation shall retrieve information about a file (value == 28)
    FunctionCode_GetFileInfo = 28,
    /// @brief Outstation shall return a file authentication key (value == 29)
    FunctionCode_AuthenticateFile = 29,
    /// @brief Outstation shall abort a file transfer operation (value == 30)
    FunctionCode_AbortFile = 30,
    /// @brief Master shall interpret this fragment as an Application Layer response to an ApplicationLayer request (value == 129)
    FunctionCode_Response = 31,
    /// @brief Master shall interpret this fragment as an unsolicited response that was not prompted by an explicit request (value == 130)
    FunctionCode_UnsolicitedResponse = 32,
} function_code_t;

static const char* FunctionCode_to_string(function_code_t value)
{
    switch (value)
    {
        case FunctionCode_Confirm: return "Confirm";
        case FunctionCode_Read: return "Read";
        case FunctionCode_Write: return "Write";
        case FunctionCode_Select: return "Select";
        case FunctionCode_Operate: return "Operate";
        case FunctionCode_DirectOperate: return "DirectOperate";
        case FunctionCode_DirectOperateNoResponse: return "DirectOperateNoResponse";
        case FunctionCode_ImmediateFreeze: return "ImmediateFreeze";
        case FunctionCode_ImmediateFreezeNoResponse: return "ImmediateFreezeNoResponse";
        case FunctionCode_FreezeClear: return "FreezeClear";
        case FunctionCode_FreezeClearNoResponse: return "FreezeClearNoResponse";
        case FunctionCode_FreezeAtTime: return "FreezeAtTime";
        case FunctionCode_FreezeAtTimeNoResponse: return "FreezeAtTimeNoResponse";
        case FunctionCode_ColdRestart: return "ColdRestart";
        case FunctionCode_WarmRestart: return "WarmRestart";
        case FunctionCode_InitializeData: return "InitializeData";
        case FunctionCode_InitializeApplication: return "InitializeApplication";
        case FunctionCode_StartApplication: return "StartApplication";
        case FunctionCode_StopApplication: return "StopApplication";
        case FunctionCode_SaveConfiguration: return "SaveConfiguration";
        case FunctionCode_EnableUnsolicited: return "EnableUnsolicited";
        case FunctionCode_DisableUnsolicited: return "DisableUnsolicited";
        case FunctionCode_AssignClass: return "AssignClass";
        case FunctionCode_DelayMeasure: return "DelayMeasure";
        case FunctionCode_RecordCurrentTime: return "RecordCurrentTime";
        case FunctionCode_OpenFile: return "OpenFile";
        case FunctionCode_CloseFile: return "CloseFile";
        case FunctionCode_DeleteFile: return "DeleteFile";
        case FunctionCode_GetFileInfo: return "GetFileInfo";
        case FunctionCode_AuthenticateFile: return "AuthenticateFile";
        case FunctionCode_AbortFile: return "AbortFile";
        case FunctionCode_Response: return "Response";
        case FunctionCode_UnsolicitedResponse: return "UnsolicitedResponse";
        default: return "";
    }
}

typedef struct request_header_t request_header_t;

/// @brief Application-layer header for requests
typedef struct request_header_t
{
    /// @brief Control field
    control_t control;
    /// @brief Function code
    function_code_t function;
} request_header_t;

static request_header_t request_header_init(control_t control, function_code_t function)
{
    return (request_header_t)
    {
        .control = control,
        .function = function,
    };
}

/// @brief Enumeration describing how the outstation processed a broadcast request
typedef enum broadcast_action_t
{
    /// @brief Outstation processed the broadcast
    BroadcastAction_Processed = 0,
    /// @brief Outstation ignored the broadcast message b/c it is disabled by configuration
    BroadcastAction_IgnoredByConfiguration = 1,
    /// @brief Outstation was unable to parse the object headers and ignored the request
    BroadcastAction_BadObjectHeaders = 2,
    /// @brief Outstation ignore the broadcast message b/c the function is not supported via Broadcast
    BroadcastAction_UnsupportedFunction = 3,
} broadcast_action_t;

static const char* BroadcastAction_to_string(broadcast_action_t value)
{
    switch (value)
    {
        case BroadcastAction_Processed: return "Processed";
        case BroadcastAction_IgnoredByConfiguration: return "IgnoredByConfiguration";
        case BroadcastAction_BadObjectHeaders: return "BadObjectHeaders";
        case BroadcastAction_UnsupportedFunction: return "UnsupportedFunction";
        default: return "";
    }
}

/// @brief Informational callbacks that the outstation doesn't rely on to function
/// 
/// It may be useful to certain applications to assess the health of the communication or to count statistics
typedef struct outstation_information_t
{
    
    /// @brief Called when a request is processed from the IDLE state
    /// @param header Request header
    /// @param ctx Context data
    void (*process_request_from_idle)(request_header_t, void*);
    
    /// @brief Called when a broadcast request is received by the outstation
    /// @param function_code Function code received
    /// @param action Broadcast action
    /// @param ctx Context data
    void (*broadcast_received)(function_code_t, broadcast_action_t, void*);
    
    /// @brief Outstation has begun waiting for a solicited confirm
    /// @param ecsn Expected sequence number
    /// @param ctx Context data
    void (*enter_solicited_confirm_wait)(uint8_t, void*);
    
    /// @brief Failed to receive a solicited confirm before the timeout occurred
    /// @param ecsn Expected sequence number
    /// @param ctx Context data
    void (*solicited_confirm_timeout)(uint8_t, void*);
    
    /// @brief Received the expected confirm
    /// @param ecsn Expected sequence number
    /// @param ctx Context data
    void (*solicited_confirm_received)(uint8_t, void*);
    
    /// @brief Received a new request while waiting for a solicited confirm, aborting the response series
    /// @param header Request header
    /// @param ctx Context data
    void (*solicited_confirm_wait_new_request)(request_header_t, void*);
    
    /// @brief Received a solicited confirm with the wrong sequence number
    /// @param ecsn Expected sequence number
    /// @param seq Received sequence number
    /// @param ctx Context data
    void (*wrong_solicited_confirm_seq)(uint8_t, uint8_t, void*);
    
    /// @brief Received a confirm when not expecting one
    /// @param unsolicited True if it's an unsolicited response confirm, false if it's a solicited response confirm
    /// @param seq Received sequence number
    /// @param ctx Context data
    void (*unexpected_confirm)(bool, uint8_t, void*);
    
    /// @brief Outstation has begun waiting for an unsolicited confirm
    /// @param ecsn Expected sequence number
    /// @param ctx Context data
    void (*enter_unsolicited_confirm_wait)(uint8_t, void*);
    
    /// @brief Failed to receive an unsolicited confirm before the timeout occurred
    /// @param ecsn Expected sequence number
    /// @param retry Is it a retry
    /// @param ctx Context data
    void (*unsolicited_confirm_timeout)(uint8_t, bool, void*);
    
    /// @brief Master confirmed an unsolicited message
    /// @param ecsn Expected sequence number
    /// @param ctx Context data
    void (*unsolicited_confirmed)(uint8_t, void*);
    
    /// @brief Master cleared the restart IIN bit
    /// @param ctx Context data
    void (*clear_restart_iin)(void*);
    /// @brief Callback when the underlying owner doesn't need the callback anymore
    /// @param arg Context data
    void (*on_destroy)(void* arg);
    /// @brief Context data
    void* ctx;
} outstation_information_t;

/// @brief Enumeration received from an outstation in response to command request
typedef enum command_status_t
{
    /// @brief command was accepted, initiated, or queued (value == 0)
    CommandStatus_Success = 0,
    /// @brief command timed out before completing (value == 1)
    CommandStatus_Timeout = 1,
    /// @brief command requires being selected before operate, configuration issue (value == 2)
    CommandStatus_NoSelect = 2,
    /// @brief bad control code or timing values (value == 3)
    CommandStatus_FormatError = 3,
    /// @brief command is not implemented (value == 4)
    CommandStatus_NotSupported = 4,
    /// @brief command is all ready in progress or its all ready in that mode (value == 5)
    CommandStatus_AlreadyActive = 5,
    /// @brief something is stopping the command, often a local/remote interlock (value == 6)
    CommandStatus_HardwareError = 6,
    /// @brief the function governed by the control is in local only control (value == 7)
    CommandStatus_Local = 7,
    /// @brief the command has been done too often and has been throttled (value == 8)
    CommandStatus_TooManyOps = 8,
    /// @brief the command was rejected because the device denied it or an RTU intercepted it (value == 9)
    CommandStatus_NotAuthorized = 9,
    /// @brief command not accepted because it was prevented or inhibited by a local automation process, such as interlocking logic or synchrocheck (value == 10)
    CommandStatus_AutomationInhibit = 10,
    /// @brief command not accepted because the device cannot process any more activities than are presently in progress (value == 11)
    CommandStatus_ProcessingLimited = 11,
    /// @brief command not accepted because the value is outside the acceptable range permitted for this point (value == 12)
    CommandStatus_OutOfRange = 12,
    /// @brief command not accepted because the outstation is forwarding the request to another downstream device which reported LOCAL (value == 13)
    CommandStatus_DownstreamLocal = 13,
    /// @brief command not accepted because the outstation has already completed the requested operation (value == 14)
    CommandStatus_AlreadyComplete = 14,
    /// @brief command not accepted because the requested function is specifically blocked at the outstation (value == 15)
    CommandStatus_Blocked = 15,
    /// @brief command not accepted because the operation was cancelled (value == 16)
    CommandStatus_Canceled = 16,
    /// @brief command not accepted because another master is communicating with the outstation and has exclusive rights to operate this control point (value == 17)
    CommandStatus_BlockedOtherMaster = 17,
    /// @brief command not accepted because the outstation is forwarding the request to another downstream device which cannot be reached or is otherwise incapable of performing the request (value == 18)
    CommandStatus_DownstreamFail = 18,
    /// @brief (deprecated) indicates the outstation shall not issue or perform the control operation (value == 126)
    CommandStatus_NonParticipating = 19,
    /// @brief aptures any value not defined in the enumeration
    CommandStatus_Unknown = 20,
} command_status_t;

static const char* CommandStatus_to_string(command_status_t value)
{
    switch (value)
    {
        case CommandStatus_Success: return "Success";
        case CommandStatus_Timeout: return "Timeout";
        case CommandStatus_NoSelect: return "NoSelect";
        case CommandStatus_FormatError: return "FormatError";
        case CommandStatus_NotSupported: return "NotSupported";
        case CommandStatus_AlreadyActive: return "AlreadyActive";
        case CommandStatus_HardwareError: return "HardwareError";
        case CommandStatus_Local: return "Local";
        case CommandStatus_TooManyOps: return "TooManyOps";
        case CommandStatus_NotAuthorized: return "NotAuthorized";
        case CommandStatus_AutomationInhibit: return "AutomationInhibit";
        case CommandStatus_ProcessingLimited: return "ProcessingLimited";
        case CommandStatus_OutOfRange: return "OutOfRange";
        case CommandStatus_DownstreamLocal: return "DownstreamLocal";
        case CommandStatus_AlreadyComplete: return "AlreadyComplete";
        case CommandStatus_Blocked: return "Blocked";
        case CommandStatus_Canceled: return "Canceled";
        case CommandStatus_BlockedOtherMaster: return "BlockedOtherMaster";
        case CommandStatus_DownstreamFail: return "DownstreamFail";
        case CommandStatus_NonParticipating: return "NonParticipating";
        case CommandStatus_Unknown: return "Unknown";
        default: return "";
    }
}

/// @brief Enumeration describing how the master requested the control operation
typedef enum operate_type_t
{
    /// @brief control point was properly selected before the operate request
    OperateType_SelectBeforeOperate = 0,
    /// @brief operate the control via a DirectOperate request
    OperateType_DirectOperate = 1,
    /// @brief operate the control via a DirectOperateNoAck request
    OperateType_DirectOperateNoAck = 2,
} operate_type_t;

static const char* OperateType_to_string(operate_type_t value)
{
    switch (value)
    {
        case OperateType_SelectBeforeOperate: return "SelectBeforeOperate";
        case OperateType_DirectOperate: return "DirectOperate";
        case OperateType_DirectOperateNoAck: return "DirectOperateNoAck";
        default: return "";
    }
}

/// @brief Callbacks for handling controls
typedef struct control_handler_t
{
    
    /// @brief Notifies the start of a command fragment
    /// @param ctx Context data
    void (*begin_fragment)(void*);
    
    /// @brief Notifies the end of a command fragment
    /// @param ctx Context data
    void (*end_fragment)(void*);
    
    /// @brief Select a CROB, but do not operate
    /// 
    /// Implementors can think of this function ask the question "is this control supported"?
    /// 
    /// Most implementations should not alter the database in this method. It is only provided in the event that some event counters reflected via the API get updated on SELECT, but this would be highly abnormal.
    /// @param control Received CROB
    /// @param index Index of the point
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*select_g12v1)(g12v1_t, uint16_t, database_t*, void*);
    
    /// @brief Operate a control point
    /// @param control Received CROB
    /// @param index Index of the point
    /// @param op_type Operate type
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*operate_g12v1)(g12v1_t, uint16_t, operate_type_t, database_t*, void*);
    
    /// @brief Select an analog output, but do not operate
    /// 
    /// Implementors can think of this function ask the question "is this control supported"?
    /// 
    /// Most implementations should not alter the database in this method. It is only provided in the event that some event counters reflected via the API get updated on SELECT, but this would be highly abnormal.
    /// @param control Received analog output value
    /// @param index Index of the point
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*select_g41v1)(int32_t, uint16_t, database_t*, void*);
    
    /// @brief Operate a control point
    /// @param control Received analog output value
    /// @param index Index of the point
    /// @param op_type Operate type
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*operate_g41v1)(int32_t, uint16_t, operate_type_t, database_t*, void*);
    
    /// @brief Select an analog output, but do not operate
    /// 
    /// Implementors can think of this function ask the question "is this control supported"?
    /// 
    /// Most implementations should not alter the database in this method. It is only provided in the event that some event counters reflected via the API get updated on SELECT, but this would be highly abnormal.
    /// @param value Received analog output value
    /// @param index Index of the point
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*select_g41v2)(int16_t, uint16_t, database_t*, void*);
    
    /// @brief Operate a control point
    /// @param value Received analog output value
    /// @param index Index of the point
    /// @param op_type Operate type
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*operate_g41v2)(int16_t, uint16_t, operate_type_t, database_t*, void*);
    
    /// @brief Select an analog output, but do not operate
    /// 
    /// Implementors can think of this function ask the question "is this control supported"?
    /// 
    /// Most implementations should not alter the database in this method. It is only provided in the event that some event counters reflected via the API get updated on SELECT, but this would be highly abnormal.
    /// @param value Received analog output value
    /// @param index Index of the point
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*select_g41v3)(float, uint16_t, database_t*, void*);
    
    /// @brief Operate a control point
    /// @param value Received analog output value
    /// @param index Index of the point
    /// @param op_type Operate type
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*operate_g41v3)(float, uint16_t, operate_type_t, database_t*, void*);
    
    /// @brief Select an analog output, but do not operate
    /// 
    /// Implementors can think of this function ask the question "is this control supported"?
    /// 
    /// Most implementations should not alter the database in this method. It is only provided in the event that some event counters reflected via the API get updated on SELECT, but this would be highly abnormal.
    /// @param value Received analog output value
    /// @param index Index of the point
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*select_g41v4)(double, uint16_t, database_t*, void*);
    
    /// @brief Operate a control point
    /// @param value Received analog output value
    /// @param index Index of the point
    /// @param op_type Operate type
    /// @param database Database
    /// @param ctx Context data
    /// @return Command status
    command_status_t (*operate_g41v4)(double, uint16_t, operate_type_t, database_t*, void*);
    /// @brief Callback when the underlying owner doesn't need the callback anymore
    /// @param arg Context data
    void (*on_destroy)(void* arg);
    /// @brief Context data
    void* ctx;
} control_handler_t;

/// @brief 
typedef struct address_filter_t address_filter_t;

/// @brief Create an address filter that accepts any IP address
/// @return Address filter
address_filter_t* address_filter_any();

/// @brief Create an address filter that accepts any IP address
/// @param address IP address to accept
/// @return Address filter
address_filter_t* address_filter_new(const char* address);

/// @brief Add an accepted IP address to the filter
/// @param address_filter Address filter to modify
/// @param address IP address to add
void address_filter_add(address_filter_t* address_filter, const char* address);

/// @brief Destroy an address filter
/// @param address_filter Address filter to destroy
void address_filter_destroy(address_filter_t* address_filter);


/// @brief TCP server that listens for connections and routes the messages to outstations.
/// 
/// To add outstations to it, use @ref tcpserver_add_outstation. Once all the outstations are added, the server can be started with @ref tcpserver_bind.
/// 
/// @ref tcpserver_destroy is used to gracefully shutdown all the outstations and the server.
typedef struct tcp_server_t tcp_server_t;

/// @brief Create a new TCP server.
/// 
/// To start it, use @ref tcpserver_bind.
/// @param runtime Runtime to execute the server on
/// @param link_error_mode Controls how link errors are handled with respect to the TCP session
/// @param address Address to bind the server to e.g. 127.0.0.1:20000
/// @return New TCP server instance
tcp_server_t* tcpserver_new(runtime_t* runtime, link_error_mode_t link_error_mode, const char* address);

/// @brief Gracefully shutdown all the outstations associated to this server, stops the server and release resources.
/// @param server Server to shutdown
void tcpserver_destroy(tcp_server_t* server);

/// @brief Add an outstation to the server.
/// 
/// The returned @ref outstation_t can be used to modify points of the outstation.
/// 
/// In order for the outstation to run, the TCP server must be running. Use @ref tcpserver_bind to run it.
/// @param server TCP server to add the outstation to
/// @param config Outstation configuration
/// @param event_config Event buffer configuration
/// @param application Outstation application callbacks
/// @param information Outstation information callbacks
/// @param control_handler Outstation control handler
/// @param filter Address filter
/// @return Outstation handle
outstation_t* tcpserver_add_outstation(tcp_server_t* server, outstation_config_t config, event_buffer_config_t event_config, outstation_application_t application, outstation_information_t information, control_handler_t control_handler, address_filter_t* filter);

/// @brief Bind the server to the port and starts listening. Also starts all the outstations associated to it.
/// @param server Server to bind
/// @return true if the bind was successful
bool tcpserver_bind(tcp_server_t* server);


#ifdef __cplusplus
}
#endif
